
-- B5906 - slow loading of Newsletter issue list
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_Activity_ActivityItemDetailID')
BEGIN
CREATE NONCLUSTERED INDEX IX_OM_Activity_ActivityItemDetailID ON OM_Activity
(
ActivityItemDetailID ASC
)
END
GO

-- B6139 - [Lead Scoring] - Missing index causes performance problems
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_ScoreContactRule_ScoreID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OM_ScoreContactRule_ScoreID]
ON [OM_ScoreContactRule] ([ScoreID])
END
GO

IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_ScoreContactRule_RuleID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OM_ScoreContactRule_RuleID]
ON [OM_ScoreContactRule] ([RuleID])
END
GO

-- TES-191 - Inactive contact delettion deletes also all contact from contact groups

GO
ALTER PROCEDURE [Proc_OM_Contact_MassDelete]
@where nvarchar(max),
	@batchLimit int
AS
BEGIN
SET NOCOUNT ON;
	-- Variables
	DECLARE @DeletedContacts TABLE (
		ContactID int NOT NULL
	);	
    DECLARE @Result TABLE (
        ContactID int NOT NULL
    );
	DECLARE @currentContactSiteID int;
	DECLARE @currentDeletedContactID int;
	DECLARE @sqlQuery NVARCHAR(MAX);
	DECLARE @listStr NVARCHAR(MAX);
	DECLARE @top NVARCHAR(20);
	
	-- Limit processed batch
	IF ((@batchLimit IS NOT NULL) OR (@batchLimit > 0))
		SET @top = 'TOP ' + CAST(@batchLimit AS NVARCHAR(10));
	ELSE 
		SET @top = 'TOP 1000';
	
	SET @sqlQuery = 'SELECT ' + @top + ' ContactID FROM OM_Contact WHERE ' + @where;
	INSERT INTO @DeletedContacts EXEC(@sqlQuery);
	
	-- Process first batch of records
	WHILE ((SELECT Count(*) FROM @DeletedContacts) > 0)
	BEGIN			
		-- Loop through records
		IF ((SELECT Count(*) FROM @DeletedContacts) > 0)
		BEGIN	
			-- Add merged contacts to deleted list
			SELECT @listStr = COALESCE(@listStr+',' ,'') + CAST(ContactID AS nvarchar(10)) FROM @DeletedContacts;
			INSERT INTO @DeletedContacts SELECT * FROM Func_OM_Contact_GetChildren_Multiple(@listStr, 1);
			
			/* Remove all references */
			UPDATE o SET o.AccountPrimaryContactID = NULL FROM OM_Account o INNER JOIN @DeletedContacts d ON o.AccountPrimaryContactID = d.ContactID;
			UPDATE o SET o.AccountSecondaryContactID = NULL FROM OM_Account o INNER JOIN @DeletedContacts d ON o.AccountSecondaryContactID = d.ContactID;
			/* Remove all relations */
			DELETE o FROM OM_AccountContact o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID;
			DELETE o FROM OM_ContactGroupMember o LEFT JOIN @DeletedContacts d ON o.ContactGroupMemberRelatedID = d.ContactID WHERE o.ContactGroupMemberType=0 AND d.ContactID IS NOT NULL;
			DELETE o FROM OM_Membership o LEFT JOIN @DeletedContacts do ON o.OriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON o.ActiveContactID = da.ContactID WHERE do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL;
			DELETE o FROM OM_IP o LEFT JOIN @DeletedContacts do ON o.IPOriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON o.IPActiveContactID = da.ContactID WHERE do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL;
			DELETE o FROM OM_UserAgent o LEFT JOIN @DeletedContacts do ON o.UserAgentOriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON o.UserAgentActiveContactID = da.ContactID WHERE do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL;
			DELETE o FROM OM_ScoreContactRule o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID;
			/* Delete relations from depending activity */
			DELETE o FROM OM_PageVisit o INNER JOIN OM_Activity a ON o.PageVisitActivityID = a.ActivityID LEFT JOIN @DeletedContacts do ON a.ActivityOriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON a.ActivityActiveContactID = da.ContactID WHERE (do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL) AND (a.ActivityType = 'pagevisit' OR a.ActivityType = 'landingpage');
			DELETE o FROM OM_Search o INNER JOIN OM_Activity a ON o.SearchActivityID = a.ActivityID LEFT JOIN @DeletedContacts do ON a.ActivityOriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON a.ActivityActiveContactID = da.ContactID WHERE (do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL) AND (a.ActivityType = 'internalsearch' OR a.ActivityType = 'externalsearch');
			DELETE o FROM OM_Activity o LEFT JOIN @DeletedContacts do ON o.ActivityOriginalContactID = do.ContactID LEFT JOIN @DeletedContacts da ON o.ActivityActiveContactID = da.ContactID WHERE do.ContactID IS NOT NULL OR da.ContactID IS NOT NULL;
			
			-- Delete merged and parent records
			DELETE o FROM OM_Contact o INNER JOIN @DeletedContacts d ON o.ContactID = d.ContactID;

            -- Store deleted IDs before clearing batch handler
            INSERT INTO @Result SELECT DISTINCT ContactID FROM @DeletedContacts
			DELETE FROM @DeletedContacts
		END
		
		-- Get next batch
		IF (@batchLimit IS  NULL)
			INSERT INTO @DeletedContacts EXEC(@sqlQuery);
	END

    -- Return all deleted contacts IDs
    SELECT ContactID FROM @Result;
END
GO

-- TES-423 Score recalculation speed optimalization

GO
ALTER PROCEDURE [Proc_OM_Score_UpdateContactScore]
@RuleID int,
 @WhereCond nvarchar(max),
 @ContactID int,
 @RuleExpiration datetime,
 @RuleValidUnits int,
 @RuleValidFor int,
 @IncludePageVisitData bit
AS
BEGIN
	DECLARE @ruleType int;
	DECLARE @ruleScoreID int;
	DECLARE @ruleValue int;
	DECLARE @ruleParameter nvarchar(250);
	DECLARE @ruleIsRecurring bit;
	DECLARE @ruleSiteID int;
	DECLARE @ruleMaxPoints int;
	DECLARE @currentContactID int;
	DECLARE @previousContactID int;
	DECLARE @currentPoints int;
	DECLARE @currentExpiration datetime;
	DECLARE @expirationDate nvarchar(300);
	DECLARE @timeRestriction nvarchar(300);
	-- Exception handling
	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorNumber INT;
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;
	DECLARE @maxValue int;
	-- Get rule info
	SELECT @ruleSiteID=[RuleSiteID], @ruleType=[RuleType], @ruleScoreID=[RuleScoreID], @ruleValue=[RuleValue], @ruleParameter=[RuleParameter], @ruleIsRecurring=[RuleIsRecurring],
	@ruleMaxPoints=[RuleMaxPoints] FROM OM_Rule WHERE RuleID=@RuleID

	------------------------------------------ Activity rule
	IF @ruleType=0
	BEGIN
		IF @ContactID=0 OR @ContactID IS NULL
		BEGIN
		  -- Retrieve all contacts for specified condition
		  SET @WhereCond = 'ContactMergedWithContactID IS NULL AND ContactSiteID=' + CAST(@ruleSiteID as varchar(15)) + ' AND (' + @WhereCond + ')
				  AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + CAST(@ruleScoreID as varchar(15)) + ' AND RuleID = ' + CAST(@RuleID as varchar(15)) + ')';
		END
		ELSE
		BEGIN
		  -- Try to retrieve given contact for specified condition
		  SET @WhereCond = 'ContactMergedWithContactID IS NULL AND ContactID=' + CAST(@ContactID as varchar(50)) + ' AND (' + @WhereCond + ')
		  AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + CAST(@ruleScoreID as varchar(15)) + ' AND RuleID = ' + CAST(@RuleID as varchar(15)) + ' AND ContactID=' + CAST(@ContactID as varchar(15)) + ')';
		END
		-- Prepare expiration date query
		SET @expirationDate =
		CASE @RuleValidUnits
		   WHEN 0 THEN 'DATEADD(dd, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
		   WHEN 1 THEN 'DATEADD(wk, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
		   WHEN 2 THEN 'DATEADD(mm, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
		   WHEN 3 THEN 'DATEADD(yy, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
		   ELSE ISNULL('''' + CAST(@RuleExpiration as varchar(250)) + '''', 'NULL') + ' AS ActCreated'
		END;
		-- Prepare time restriction in the past for time interval activities
		SET @timeRestriction =
		CASE @RuleValidUnits
		   WHEN 0 THEN 'ActivityCreated >= DATEADD(dd, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE()) AND '
		   WHEN 1 THEN 'ActivityCreated >= DATEADD(wk, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE()) AND '
		   WHEN 2 THEN 'ActivityCreated >= DATEADD(mm, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE()) AND '
		   WHEN 3 THEN 'ActivityCreated >= DATEADD(yy, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE()) AND '
		   ELSE ''
		END;
		-- Join additional table for page visit and landing page
		IF @ruleParameter='pagevisit' OR @ruleParameter='landingpage'
		BEGIN
		  BEGIN TRY
			DECLARE @pageViewAditionalJoinTables varchar(100);
		
			-- Join OM_PageVisit table when where condition uses data from this table
			IF @IncludePageVisitData=1
			BEGIN
				SET @pageViewAditionalJoinTables = 'LEFT JOIN OM_PageVisit ON OM_Activity.ActivityID=OM_PageVisit.PageVisitActivityID ';
			END

			EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', COUNT(ContactID)*' + @ruleValue + ', ' + @expirationDate + 
			' FROM OM_Activity 
			INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID ' +
			@pageViewAditionalJoinTables +
			'WHERE ' + @timeRestriction + ' (' + @WhereCond + ') 
			GROUP BY ContactID');
		  END TRY
		  BEGIN CATCH
			-- Get error info
			SELECT @ErrorNumber = ERROR_NUMBER(), @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        
			IF @ErrorNumber = 8115   -- Is it arithmetic overflow error?
			BEGIN
			  IF (@ruleValue >= 0)
		  SET @maxValue = 2147483647;
			  ELSE
				 SET @maxValue = -2147483647;
			  -- Set max value
			  EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', ' + @maxValue + ', ' + @expirationDate + 
			  ' FROM OM_Activity INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID LEFT JOIN OM_PageVisit ON OM_Activity.ActivityID=OM_PageVisit.PageVisitActivityID ' +
			  'WHERE ' + @timeRestriction + ' (' + @WhereCond + ') GROUP BY ContactID');
			END
			ELSE
			BEGIN
			  RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
			END      
		  END CATCH
		END
		ELSE
		BEGIN
		  -- Join additional table for internal and external search 
		  IF @ruleParameter='internalsearch' OR @ruleParameter='externalsearch'
		  BEGIN
			BEGIN TRY

			EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', COUNT(ContactID)*' + @ruleValue + ', ' + @expirationDate + 
			  ' FROM OM_Activity INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID LEFT JOIN OM_Search ON OM_Activity.ActivityID=OM_Search.SearchActivityID WHERE ' +
			   @timeRestriction + ' (' + @WhereCond + ') GROUP BY ContactID');
			END TRY
			BEGIN CATCH
			  -- Get error info
			  SELECT @ErrorNumber = ERROR_NUMBER(), @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        
			  IF @ErrorNumber = 8115   -- Is it arithmetic overflow error?
			  BEGIN
				IF (@ruleValue >= 0)
				   SET @maxValue = 2147483647;
				ELSE
				   SET @maxValue = -2147483647;
				-- Set max value
				EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', ' + @maxValue + ', ' + @expirationDate +             
				' FROM OM_Activity INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID LEFT JOIN OM_Search ON OM_Activity.ActivityID=OM_Search.SearchActivityID ' +
				'WHERE ' + @timeRestriction + ' (' + @WhereCond + ') GROUP BY ContactID');
			  END
			  ELSE
			  BEGIN
				RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
			  END      
			END CATCH         
		  END
		  ELSE
		  BEGIN
			BEGIN TRY
			  EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', COUNT(ContactID)*' + @ruleValue + ', ' + @expirationDate +         
			  ' FROM OM_Activity INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID WHERE ' + @timeRestriction +
			  ' (' + @WhereCond + ') GROUP BY ContactID');
			END TRY
			BEGIN CATCH
			  -- Get error info
			  SELECT @ErrorNumber = ERROR_NUMBER(), @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
        
			  IF @ErrorNumber = 8115   -- Is it arithmetic overflow error?
			  BEGIN
				IF (@ruleValue >= 0)
				   SET @maxValue = 2147483647;
				ELSE
				   SET @maxValue = -2147483647;
				-- Set max value
				EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', ' + @maxValue + ', ' + @expirationDate +                        
				' FROM OM_Activity INNER JOIN OM_Contact ON OM_Contact.ContactID=OM_Activity.ActivityActiveContactID WHERE ' + @timeRestriction +
				' (' + @WhereCond + ') GROUP BY ContactID');
			  END
			  ELSE
			  BEGIN
				RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
			  END      
			END CATCH
		  END
		END
   
		-- Set (update) correct points for non-recurring activities
		IF @ruleIsRecurring=0
		BEGIN    
		  UPDATE OM_ScoreContactRule SET Value = @ruleValue WHERE ScoreID = @ruleScoreID AND RuleID = @RuleID;
		END
		ELSE
		BEGIN
		  IF (@ruleMaxPoints IS NOT NULL) AND (@ruleMaxPoints <> 0)
		  BEGIN
			 IF @ruleMaxPoints > 0
			   UPDATE OM_ScoreContactRule SET Value = @ruleMaxPoints WHERE Value > @ruleMaxPoints AND ScoreID = @ruleScoreID AND RuleID = @RuleID;
			 ELSE
			   UPDATE OM_ScoreContactRule SET Value = @ruleMaxPoints WHERE Value < @ruleMaxPoints AND ScoreID = @ruleScoreID AND RuleID = @RuleID;
		  END
		END
	------------------------------------------ Attribute rule    
	END ELSE IF @ruleType=1
	BEGIN
		IF @ContactID=0 OR @ContactID IS NULL
		BEGIN
		  -- Retrieve all contacts for specified condition
		  EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', ' + @ruleValue + ', NULL 
			FROM OM_Contact
			WHERE ContactMergedWithContactID IS NULL AND ContactSiteID=' + @ruleSiteID + ' AND (' + @WhereCond + ') 
				AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + @ruleScoreID + ' AND RuleID = ' + @RuleID + ')');     
		END
		ELSE
		BEGIN
		  -- Try to retrieve given contact for specified condition
		  EXEC ('INSERT INTO OM_ScoreContactRule SELECT ' + @ruleScoreID + ', ContactID, ' + @RuleID + ', ' + @ruleValue + ', NULL 
			FROM OM_Contact
			WHERE ContactMergedWithContactID IS NULL AND ContactID=' + @ContactID + ' AND (' + @WhereCond + ')
				AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + @ruleScoreID  + ' AND RuleID = ' +@RuleID + 'AND ContactID=' + @ContactID + ')');     
		END
	END
END
GO

--- TES-452 Deleting a newsletter issue caused an error in certain scenarios when the online marketing database was separated

GO
ALTER PROCEDURE [Proc_Newsletter_Issue_RemoveOMDependencies]
@IssueIDs nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @tbl_string Table (ParsedString nvarchar(max))
	DECLARE	@end Int,
			@start Int,
			@stringArray nvarchar(max)
	SET @stringArray =  @IssueIDs + ','
	SET @start=1
	SET @end=1
	WHILE @end<Len(@stringArray)
		BEGIN
			SET @end = CharIndex(',', @stringArray, @end)
			INSERT INTO @tbl_string
				SELECT
					Substring(@stringArray, @start, @end-@start)
			SET @start=@end+1
			SET @end = @end+1
		END

	BEGIN TRANSACTION;
	-- Newsletter_SubscriberLink
	DELETE FROM Newsletter_SubscriberLink WHERE LinkID IN
		(SELECT LinkID FROM Newsletter_Link WHERE LinkIssueID IN (SELECT ParsedString FROM @tbl_string));
	-- Newsletter_Link
	DELETE FROM Newsletter_Link WHERE LinkIssueID IN (SELECT ParsedString FROM @tbl_string);
	-- Newsletter_OpenedEmail
	DELETE FROM Newsletter_OpenedEmail WHERE IssueID IN (SELECT ParsedString FROM @tbl_string);
	COMMIT TRANSACTION;
END
GO
