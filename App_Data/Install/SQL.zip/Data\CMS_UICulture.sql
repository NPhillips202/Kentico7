SET IDENTITY_INSERT [CMS_UICulture] ON
INSERT INTO [CMS_UICulture] ([UICultureID], [UICultureName], [UICultureCode], [UICultureGUID], [UICultureLastModified]) VALUES (88, N'Czech', N'cs-cz', '5b48280b-a434-4876-9b7d-0eec165dcc1b', '20120109 00:12:21')
INSERT INTO [CMS_UICulture] ([UICultureID], [UICultureName], [UICultureCode], [UICultureGUID], [UICultureLastModified]) VALUES (11, N'English', N'en-us', '356a7bb3-5b11-4d83-bbc4-964aafd6d60a', '20120110 18:55:23')
SET IDENTITY_INSERT [CMS_UICulture] OFF
