-- B5433 - Team development - My desk > Checked out objects - edit action for email template is missing
GO
UPDATE [CMS_Class] SET [ClassEditingPageURL] = N'~/CMSModules/EmailTemplates/Pages/Frameset.aspx?templateid={%EditedObject.ID%}&&tabmode=1&editonlycode=1' WHERE [ClassName] = N'cms.emailtemplate'
GO

-- B5477 - [Team development] - UIForm checks out all new objects, not only objects that support locking
GO
DELETE FROM [CMS_ObjectSettings] WHERE [ObjectSettingsObjectType] NOT IN ('cms.layout','cms.templatedevicelayout','cms.pagetemplate','cms.emailtemplate','cms.transformation','cms.cssstylesheet','cms.webpartcontainer','cms.webpartlayout')
GO

-- B5563 - [General] - SQL exception while deleting module
GO
ALTER PROCEDURE [Proc_CMS_Resource_RemoveDependencies]
	@ID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;    
    DELETE FROM [CMS_ResourceSite] WHERE ResourceID = @ID;
	
	-- Permissions
    DELETE FROM [Forums_ForumRoles]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_RolePermission]			WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Community_GroupRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Media_LibraryRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_WidgetRole]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
	DELETE FROM [CMS_Permission] WHERE ResourceID = @ID;

    -- UI elements
    DELETE FROM [CMS_RoleUIElement] WHERE ElementID IN (SELECT ElementID FROM CMS_UIElement WHERE ElementResourceID = @ID);
    DELETE FROM [CMS_UIElement] WHERE ElementResourceID = @ID;
    
    UPDATE [CMS_WebPart] SET WebPartResourceID = NULL WHERE WebPartResourceID = @ID;
    UPDATE [CMS_FormUserControl] SET UserControlResourceID = NULL WHERE UserControlResourceID = @ID;
    UPDATE [CMS_InlineControl] SET ControlResourceID = NULL WHERE ControlResourceID = @ID;
    UPDATE [CMS_ScheduledTask] SET TaskResourceID = NULL WHERE TaskResourceID = @ID;
	UPDATE [CMS_WorkflowAction] SET ActionResourceID = NULL WHERE ActionResourceID = @ID;
        
	COMMIT TRANSACTION;
END
GO

-- B6148 - [Workflow] - SQL exception while deleting culture assigned to workflow scope
GO
ALTER PROCEDURE [Proc_CMS_Culture_RemoveDependencies] 
    @ID int
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    -- Delete dependencies from CMS_UserCulture
    DELETE FROM CMS_UserCulture WHERE CultureID = @ID;
	-- CMS_WorkflowScope
    DELETE FROM CMS_WorkflowScope WHERE ScopeCultureID = @ID;
    -- CMS_SiteCulture
    DELETE FROM CMS_SiteCulture WHERE CultureID = @ID;
    -- BadWords_WordCulture
    DELETE FROM BadWords_WordCulture WHERE CultureID = @ID;   
    -- Search index
    DELETE FROM [CMS_SearchIndexCulture] WHERE IndexCultureID = @ID;
    
    -- CMS Page template scopes
    DELETE FROM [CMS_PageTemplateScope] WHERE PageTemplateScopeCultureID = @ID;
    
    COMMIT TRANSACTION;
END
GO


-- B5621 - [Web parts] - Google analytics doesn't support some multiple subdomain scenarios
GO
UPDATE [CMS_WebPart]
SET [WebPartProperties] = '<form><category name="Google Analytics Settings" visible="True" /><field column="TrackingCode" fieldcaption="Tracking code" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="20" fielddescription="This code is obtained from the Google Analytics service at www.google.com/analytics." publicfield="false" spellcheck="false" guid="47bb33c6-3432-4fee-8dd2-204d2552ad5d" visibility="none"><settings><controlname>textboxcontrol</controlname></settings></field><field column="TrackingType" fieldcaption="Tracking type" visible="true" defaultvalue="0" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="Type of the tracking depending on the domain model." publicfield="false" spellcheck="false" guid="0b69524d-3de0-440d-9c07-ec39ab5ecae5" visibility="none"><settings><controlname>radiobuttonscontrol</controlname><RepeatDirection>vertical</RepeatDirection><Options>0; Single domain (e.g. only www.example.com)
1; One domain with multiple subdomains (e.g. sub1.example.com, sub2.example.com, sub3.example.com)
2; Multiple top-level domains (e.g. www.example.com, www.example.net, www.example.org)</Options></settings></field><field column="MainWebsiteDomain" fieldcaption="Website main domain" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" fielddescription="Use this property to specify a custom domain name used for tracking purposes in non-trivial scenarios. For example, if you want to track visits to &quot;my.first.example.com&quot; and &quot;my.second.example.com&quot;, which  are both subdomains of &quot;example.com&quot;, fill in &quot;example.com&quot;. If you leave the property empty, the web part will use the current domain." publicfield="false" guid="9b514025-ca06-44d1-8f9a-c8a503ef8926" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field><field column="UseAsyncScript" fieldcaption="Use asynchronous script" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates if asynchronous variant of Google analytics script should be used." publicfield="false" spellcheck="false" guid="3f158398-bbf7-4061-8131-5777c6b2b04f" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
WHERE [WebPartName]= N'GoogleAnalytics'
GO


-- B5562 - Custom table item selector form control in not working
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 2
BEGIN
	UPDATE [CMS_FormUserControl] SET UserControlParameters = '<form><field column="CustomTable" fieldcaption="Custom table" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Selects from which custom table the items will be offered." publicfield="false" guid="ecbd7716-cf7f-4b30-a62d-112b2c301a95" visibility="none"><settings><controlname>customtableselector</controlname></settings></field><field column="DisplayNameFormat" fieldcaption="Format of the display name" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="400" fielddescription="Determines the format of the item names displayed in the selector. You can use macros in format {%ColumnName%} to dynamically retrieve values of specific items." publicfield="false" guid="610bf2db-dffb-446f-b9e8-a2b45cdb1eee" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="ReturnColumnName" fieldcaption="Name of the value column" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Specifies the column from which the value stored by the selector will be loaded. This must be a unique identifier for the given custom table." publicfield="false" guid="add37892-aca1-403c-8714-444fb950765a" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field></form>'
		WHERE UserControlCodeName = 'CustomTableItemSelector'
END
GO

-- B5657 - Facebook - Update setting (from global setting to site setting)
GO
IF (SELECT TOP 1 KeyIsGlobal FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey') = 1
BEGIN
	DECLARE @categoryID int;
	DECLARE @currentSiteID int;
	DECLARE @counter int;
	DECLARE @rowCount int;
	DECLARE @siteTable TABLE (SiteID INT NOT NULL);


	INSERT INTO @siteTable SELECT SiteID FROM CMS_Site ORDER BY SiteID ASC;
	SET @rowCount = (SELECT COUNT(SiteID) FROM @siteTable);
	SET @counter = 0;
	SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
	SET @categoryID = (SELECT TOP 1 KeyCategoryID FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey');

	UPDATE CMS_SettingsKey SET
		KeyIsGlobal = 0
	WHERE KeyName LIKE 'CMSFacebookConnectApiKey';

	WHILE @counter < @rowCount
	BEGIN
		INSERT INTO CMS_SettingsKey
		(KeyName, KeyDisplayName, KeyDescription, KeyType, KeyCategoryID, KeyGUID, KeyLastModified, KeyOrder, SiteID)
		VALUES ('CMSFacebookConnectApiKey', '{$settingskey.cmsfacebookconnectapikey$}', '{$settingskey.cmsfacebookconnectapikey.description$}',
		'string', @categoryID, NEWID(), GETDATE(), 1, @currentSiteID );
		DELETE FROM @siteTable WHERE SiteID = @currentSiteID;
		SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
		SET @counter = @counter + 1    
	END;
END;
GO

--B5726 - Route document aliases are not redirected to the main alias
-- DM-509 - Cached PageInfo object did not contain correct document alias data (campaign, etc.)
DROP VIEW [View_CMS_DocumentAlias_Joined]
GO

CREATE VIEW [View_CMS_DocumentAlias_Joined]
AS
SELECT     CMS_Tree.NodeAliasPath, CMS_DocumentAlias.AliasNodeID, CMS_DocumentAlias.AliasCulture, CMS_DocumentAlias.AliasURLPath, 
                      CMS_DocumentAlias.AliasSiteID, CMS_DocumentAlias.AliasActionMode, CMS_DocumentAlias.AliasCampaign
FROM         CMS_DocumentAlias INNER JOIN
                      CMS_Tree ON CMS_DocumentAlias.AliasNodeID = CMS_Tree.NodeID
GO

--B5756 - Update stored procedure Proc_CMS_Class_Insert
GO
ALTER PROCEDURE [Proc_CMS_Class_Insert]
	@ClassID int = NULL,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,    
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,    
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
INSERT INTO [CMS_Class] (
    [ClassDisplayName],
    [ClassName],
    [ClassUsesVersioning],
    [ClassIsDocumentType],
    [ClassIsCoupledClass],
    [ClassXmlSchema],
    [ClassFormDefinition],
    [ClassNewPageUrl],
    [ClassEditingPageUrl],
    [ClassListPageUrl],
    [ClassNodeNameSource],    
    [ClassTableName],
    [ClassViewPageUrl],
    [ClassPreviewPageUrl],
    [ClassFormLayout],
    [ClassShowAsSystemTable],
    [ClassUsePublishFromTo],
    [ClassShowTemplateSelection],
    [ClassSKUMappings],
    [ClassIsMenuItemType],
    [ClassNodeAliasSource],
    [ClassDefaultPageTemplateID],    
    [ClassSKUDefaultDepartmentID],
    [ClassSKUDefaultDepartmentName],
    [ClassLastModified],
    [ClassGUID],
    [ClassCreateSKU],
    [ClassIsProduct],    
    [ClassIsCustomTable],
    [ClassShowColumns],
    [ClassLoadGeneration],
	[ClassSearchTitleColumn],
	[ClassSearchContentColumn],
	[ClassSearchImageColumn],
    [ClassSearchCreationDateColumn],
    [ClassSearchSettings],
    [ClassInheritsFromClassID],
    [ClassSearchEnabled],
    [ClassContactMapping],
    [ClassContactOverwriteEnabled],
    [ClassSKUDefaultProductType],
    [ClassConnectionString],
    [ClassIsProductSection],
    [ClassPageTemplateCategoryID]
)
VALUES (
    @ClassDisplayName, 
    @ClassName, 
    @ClassUsesVersioning, 
    @ClassIsDocumentType, 
    @ClassIsCoupledClass, 
    @ClassXmlSchema, 
    @ClassFormDefinition, 
    @ClassNewPageUrl, 
    @ClassEditingPageUrl, 
    @ClassListPageUrl, 
    @ClassNodeNameSource, 
    @ClassTableName,
    @ClassViewPageUrl,
    @ClassPreviewPageUrl,
    @ClassFormLayout,
    @ClassShowAsSystemTable,
    @ClassUsePublishFromTo,
    @ClassShowTemplateSelection,
    @ClassSKUMappings,
    @ClassIsMenuItemType,
    @ClassNodeAliasSource,
    @ClassDefaultPageTemplateID,    
    @ClassSKUDefaultDepartmentID,
    @ClassSKUDefaultDepartmentName,
    @ClassLastModified,
    @ClassGUID,
    @ClassCreateSKU,
    @ClassIsProduct,    
    @ClassIsCustomTable,
    @ClassShowColumns,
    @ClassLoadGeneration,
	@ClassSearchTitleColumn,
	@ClassSearchContentColumn,
	@ClassSearchImageColumn,
    @ClassSearchCreationDateColumn,
    @ClassSearchSettings,
    @ClassInheritsFromClassID,
    @ClassSearchEnabled,
    @ClassContactMapping,
    @ClassContactOverwriteEnabled,
    @ClassSKUDefaultProductType,
    @ClassConnectionString,
    @ClassIsProductSection,
    @ClassPageTemplateCategoryID
)
SELECT SCOPE_IDENTITY()
END
GO

--B5756 - Update stored procedure Proc_CMS_Class_Update
GO
ALTER PROCEDURE [Proc_CMS_Class_Update]
	@ClassID int,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
UPDATE [CMS_Class] 
SET 
    ClassDisplayName = @ClassDisplayName,
    ClassName = @ClassName,
    ClassUsesVersioning = ClassUsesVersioning,
    ClassIsDocumentType = @ClassIsDocumentType,
    ClassIsCoupledClass = @ClassIsCoupledClass,
    ClassXmlSchema = @ClassXmlSchema,
    ClassFormDefinition = @ClassFormDefinition,
    ClassNewPageUrl = @ClassNewPageUrl,
    ClassEditingPageUrl = @ClassEditingPageUrl,
    ClassListPageUrl = @ClassListPageUrl,
    ClassNodeNameSource = @ClassNodeNameSource,
    ClassTableName = @ClassTableName,
    ClassViewPageUrl = @ClassViewPageUrl,
    ClassPreviewPageUrl = @ClassPreviewPageUrl,
    ClassFormLayout = @ClassFormLayout,
    ClassShowAsSystemTable = @ClassShowAsSystemTable,
    ClassUsePublishFromTo = @ClassUsePublishFromTo,
    ClassShowTemplateSelection = @ClassShowTemplateSelection,
    ClassSKUMappings = @ClassSKUMappings,
    ClassIsMenuItemType = @ClassIsMenuItemType,
    ClassNodeAliasSource = @ClassNodeAliasSource,
    ClassDefaultPageTemplateID = @ClassDefaultPageTemplateID, 
    ClassSKUDefaultDepartmentID = @ClassSKUDefaultDepartmentID,
    ClassSKUDefaultDepartmentName = @ClassSKUDefaultDepartmentName,
    ClassLastModified = @ClassLastModified,
    ClassGUID = @ClassGUID,
    ClassCreateSKU = @ClassCreateSKU,
    ClassIsProduct = @ClassIsProduct,
    ClassIsCustomTable = @ClassIsCustomTable,
    ClassShowColumns = @ClassShowColumns,
    ClassLoadGeneration = @ClassLoadGeneration,
    ClassSearchTitleColumn = @ClassSearchTitleColumn,
    ClassSearchContentColumn = @ClassSearchContentColumn,
    ClassSearchImageColumn = @ClassSearchImageColumn,
    ClassSearchCreationDateColumn = @ClassSearchCreationDateColumn,
    ClassSearchSettings = @ClassSearchSettings,
    ClassInheritsFromClassID = @ClassInheritsFromClassID,
    ClassSearchEnabled = @ClassSearchEnabled,
    ClassContactMapping = @ClassContactMapping,
    ClassContactOverwriteEnabled = @ClassContactOverwriteEnabled,
    ClassSKUDefaultProductType = @ClassSKUDefaultProductType,
    ClassConnectionString = @ClassConnectionString,
    ClassIsProductSection = @ClassIsProductSection,
    ClassPageTemplateCategoryID = @ClassPageTemplateCategoryID
WHERE
    ClassID = @ClassID
END
GO

-- B5756 - Update stored procedures for ordering attachment history
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_InitAttachmentOrders]
@AttachmentGUID uniqueidentifier,
@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);

	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Declare the selection table */
	DECLARE @attachmentTable TABLE (
		AttachmentHistoryID int NOT NULL,
		AttachmentName nvarchar(255) NOT NULL,
		AttachmentOrder int NULL
		
	);
	
	/* Get the grouped or unsorted attachments */
	IF @AttachmentGroupGUID IS NOT NULL
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID = @AttachmentGroupGUID AND AttachmentDocumentID=@AttachmentDocumentID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID IS NULL AND AttachmentDocumentID=@AttachmentDocumentID AND AttachmentIsUnsorted=1 AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	
	
	
	
	/* Declare the cursor to loop through the table */
	DECLARE @attachmentCursor CURSOR;
    SET @attachmentCursor = CURSOR FOR SELECT AttachmentHistoryID, AttachmentName, AttachmentOrder FROM @attachmentTable ORDER BY AttachmentOrder, AttachmentName, AttachmentHistoryID;
    
	/* Assign the numbers to the attachments */
	DECLARE @currentIndex int, @currentAttachmentOrder int, @currentAttachmentHistoryID int;
	SET @currentIndex = 1;
	
	DECLARE @currentAttachmentName nvarchar(255);
	
	/* Loop through the table */
	OPEN @attachmentCursor
	FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		/* Set the attachments' index if different */
		IF @currentAttachmentOrder IS NULL OR @currentAttachmentOrder <> @currentIndex
			UPDATE CMS_AttachmentHistory SET AttachmentOrder = @currentIndex WHERE AttachmentHistoryID = @currentAttachmentHistoryID;
		/* Get next record */
		SET @currentIndex = @currentIndex + 1;
		FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	END
	CLOSE @attachmentCursor;
	DEALLOCATE @attachmentCursor;
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentDown]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	DECLARE @MaxAttachmentOrder int
	IF @AttachmentGroupGUID IS NOT NULL
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);
	ELSE
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);		
	
	/* Move the next attachment(s) up */	
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment down */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder < @MaxAttachmentOrder
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentUp]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Move the previous attachment down */
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment up */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder > 1
END
GO

-- B5822 Page template category didn't remove referencing value in cms_class column
DECLARE @QueryClassID int;
SELECT @QueryClassID=ClassID FROM CMS_Class WHERE ClassName = N'cms.pagetemplatecategory '
IF (@QueryClassID > 0) AND NOT EXISTS(SELECT QueryID FROM CMS_Query WHERE ClassID=@QueryClassID AND QueryName= N'removedependencies' )
BEGIN
INSERT INTO CMS_Query ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked],
  [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom] ) 
  VALUES ( 'removedependencies', 1, 'Proc_CMS_PageTemplateCategory_RemoveDependencies', 0, @QueryClassID, 0, GETDATE(), NEWID(), 0, 0)
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_PageTemplateCategory_RemoveDependencies' AND [ROUTINE_TYPE]= N'PROCEDURE')
DROP PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
GO

CREATE PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
	@ID int
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	-- CMS_Class
	UPDATE CMS_Class SET ClassPageTemplateCategoryID = NULL WHERE ClassPageTemplateCategoryID = @ID
	COMMIT TRANSACTION;
END
GO



-- TES - 345 - Deleted media library did not remove also file versions
DECLARE @QueryClassID int;
SELECT @QueryClassID=ClassID FROM CMS_Class WHERE ClassName = N'media.library'
IF (@QueryClassID > 0) AND NOT EXISTS(SELECT QueryID FROM CMS_Query WHERE ClassID=@QueryClassID AND QueryName= N'removechildversions' )
BEGIN
INSERT INTO CMS_Query ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked],
  [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom] ) 
  VALUES ( 'removechildversions', 1, 'Proc_Media_Library_RemoveChildVersions', 0, @QueryClassID, 0, GETDATE(), NEWID(), 0, 0)
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_Media_Library_RemoveChildVersions' AND [ROUTINE_TYPE]= N'PROCEDURE')
	DROP PROCEDURE [Proc_Media_Library_RemoveChildVersions]
GO

CREATE PROCEDURE [Proc_Media_Library_RemoveChildVersions]
	@ID int
AS
BEGIN
	SET NOCOUNT ON;

	-- Media_file     
	DELETE FROM [CMS_ObjectVersionHistory] WHERE [VersionObjectType] = N'media.file' AND [VersionObjectID] IN (
		SELECT [FileID] FROM [Media_File] WHERE FileLibraryID = @ID
	);
END
GO


-- B5820 Conversion values listed in AB tests with same name and same node were joined through multiple sites. (the same for MVT)
UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT ABTestID,ABTestName, ABTestDisplayName, ABTestSiteID,  ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestMaxConversions, ABTestConversions, ABTestTargetConversionType, SUM (HitsValue) AS HitsValue FROM OM_ABTest 
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''abconversion;''+ ABTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_ABTest.ABTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY ABTestName, ABTestDisplayName, ABTestID, ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestConversions, ABTestSiteID, ABTestMaxConversions, ABTestTargetConversionType) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.ABTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, SUM (HitsValue) AS HitsValue,
   HitsStartTime,HitsEndTime, MVTestPage, MVTestMaxConversions, MVTestTargetConversionType  FROM OM_MVTest
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID
,HitsStartTime,HitsEndTime, MVTestMaxConversions, MVTestTargetConversionType
) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_DayHits ON Analytics_Statistics.StatisticsID = Analytics_DayHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsDays' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_HourHits ON Analytics_Statistics.StatisticsID = Analytics_HourHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsHours' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_MonthHits ON Analytics_Statistics.StatisticsID = Analytics_MonthHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsMonths' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_WeekHits ON Analytics_Statistics.StatisticsID = Analytics_WeekHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsWeeks' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsYears' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

-- B5878 - incorrect password form control for SQLDastaSource
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 9
BEGIN
	IF (SELECT UserControlID FROM CMS_FormUserControl WHERE UserControlCodeName = N'encryptedpassword') IS NOT NULL BEGIN
		UPDATE CMS_WebPart SET WebPartProperties = REPLACE(WebPartProperties, N'<settings><controlname>password</controlname></settings>', N'<settings><controlname>encryptedpassword</controlname></settings>') WHERE WebPartName = N'SQLDataSource'
	END
END 
GO

-- B5730 - Chat.CreateNewRoom UI element has it's from version field set to 6.0 not 7.0
GO
UPDATE [CMS_UIElement]
SET [ElementFromVersion] = '7.0'
WHERE [ElementName] = 'Chat.CreateNewRoom' AND [ElementFromVersion] = '6.0'
GO

-- B6076 - Room protected by a password and created in CMS Desk is not accessible to users that know the password.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 17
BEGIN
	UPDATE [CMS_Class]
	SET [ClassFormDefinition] = REPLACE([ClassFormDefinition],'<settings><controlname>passwordconfirmator</controlname><showstrength>False</showstrength></settings>','<settings><controlname>passwordstrength</controlname></settings>')
	WHERE [ClassName] = 'Chat.Room'
END
GO

-- B5948 - Global scheduled tasks did not run without a site
ALTER PROCEDURE [Proc_CMS_ScheduledTask_FetchTasksToRun]
@TaskSiteID int,
@DateTime datetime,
@TaskServerName nvarchar(100),
@UseExternalService bit = null
AS
BEGIN
DECLARE @TaskIDs TABLE (TaskID int);
BEGIN TRAN
    IF (@TaskSiteID IS NOT NULL)
    BEGIN
      /* Get tasks for specified site and global tasks that should be processed by application */
      IF (@UseExternalService = 0)
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 0 OR TaskUseExternalService IS NULL);
        END
      ELSE IF (@UseExternalService = 1)
        /* Get tasks for specified site and global tasks that should be processed by external service */
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 1);
        END
      ELSE IF (@UseExternalService IS NULL)
        /* Get tasks for specified site and global tasks */
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName);
        END
    END
    ELSE
    BEGIN
      IF (@UseExternalService = 1)
      /* Get sites and global tasks for external service (only for running sites) */
        BEGIN
            INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask
              WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND (TaskSiteID IN (SELECT SiteID FROM CMS_Site WHERE SiteStatus = N'RUNNING') OR TaskSiteID IS NULL)
              AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 1);
        END
      ELSE IF (@UseExternalService IS NULL)
      /* Get only global tasks if there is no site */
        BEGIN
            INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask
              WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND (TaskSiteID IS NULL)
              AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName);
        END
    END

UPDATE CMS_ScheduledTask SET TaskNextRunTime = NULL WHERE TaskID IN (SELECT TaskID FROM @TaskIDs);
COMMIT TRAN
SELECT * FROM @TaskIDs;
END
GO

-- B6021 - Missing index over UserAuthenticationGUID 
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_CMS_UserSettings_UserAuthenticationGUID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_CMS_UserSettings_UserAuthenticationGUID] ON [CMS_UserSettings] 
(
	[UserAuthenticationGUID]
)
END
GO

-- F21032 - Settings for JS WA logging
DECLARE @ActivityCategoryID int;
SELECT @ActivityCategoryID=[CategoryID] FROM [CMS_SettingsCategory] WHERE [CategoryName]='CMS.WebAnalytics.General'

IF @ActivityCategoryID IS NOT NULL
BEGIN
  DECLARE @GlobalActivityKey int;
  SELECT @GlobalActivityKey=[KeyID] FROM [CMS_SettingsKey] WHERE [KeyName] = 'CMSWebAnalyticsUseJavascriptLogging'  

  IF @GlobalActivityKey IS NULL
  BEGIN
    -- Insert global key
    INSERT INTO CMS_SettingsKey ([KeyName], [KeyDisplayName], [KeyDescription], [KeyValue], [KeyType], [KeyCategoryID], [SiteID], [KeyGUID], [KeyLastModified], [KeyDefaultValue], [KeyOrder])
    SELECT 'CMSWebAnalyticsUseJavascriptLogging', '{$settingskey.cmswebanalyticsusejavascriptlogging$}', '{$settingskey.cmswebanalyticsusejavascriptlogging.description$}', 'false', 'boolean', @ActivityCategoryID, NULL, NEWID(), GETDATE(), 'true', 100
    INSERT INTO CMS_SettingsKey ([KeyName], [KeyDisplayName], [KeyDescription], [KeyValue], [KeyType], [KeyCategoryID], [SiteID], [KeyGUID], [KeyLastModified], [KeyDefaultValue], [KeyOrder])
    -- Insert site key for all sites
    SELECT 'CMSWebAnalyticsUseJavascriptLogging', '{$settingskey.cmswebanalyticsusejavascriptlogging$}', '{$settingskey.cmswebanalyticsusejavascriptlogging.description$}', NULL, 'boolean', @ActivityCategoryID, SiteID, NEWID(), GETDATE(), NULL, 100
    FROM CMS_Site
  END
END
GO

-- B6078 - [Chat] - Chat old records cleaner did not delete references correctly
GO
ALTER PROCEDURE [Proc_Chat_CleanOldChatRecords]
	@DaysOld INT
AS
BEGIN
	DECLARE @Now DATETIME
	SET @Now = GETDATE()

	DECLARE @MessagesDeleted INT
	DECLARE @RoomsDeleted INT
	DECLARE @UsersDeleted INT

	-- First step: delete old messages
	DELETE CM 
	FROM Chat_Message AS CM 
	WHERE DATEDIFF(DD, CM.ChatMessageLastModified, @Now) > @DaysOld

	SET @MessagesDeleted = @@ROWCOUNT

	-- Second step: delete old rooms which are not used anymore
	DECLARE @RoomsToDelete TABLE (RoomID INT);

	-- Find unused rooms and store their IDs to table variable
	INSERT @RoomsToDelete
	SELECT CR.ChatRoomID
	FROM Chat_Room CR
	WHERE CR.ChatRoomPrivate = 1 -- private rooms only
	AND NOT EXISTS (SELECT ChatMessageID FROM Chat_Message CM WHERE CM.ChatMessageRoomID = CR.ChatRoomID) -- without messages
	AND DATEDIFF(dd, CR.ChatRoomCreatedWhen, @Now) > @DaysOld -- was created more than @DaysOld days ago
	AND NOT EXISTS (
		SELECT ChatUserID 
		FROM Chat_RoomUser CRU
		LEFT JOIN Chat_User CU ON CU.ChatUserID = CRU.ChatRoomUserChatUserID
		WHERE
		CRU.ChatRoomUserRoomID = CR.ChatRoomID
		AND
		(
			(CU.ChatUserUserID IS NOT NULL AND CRU.ChatRoomUserAdminLevel > 0) -- without non anonymous users with more than 'None' permissions
			OR (CU.ChatUserUserID IS NULL AND (CRU.ChatRoomUserJoinTime IS NOT NULL OR DATEDIFF(dd, CRU.ChatRoomUserLeaveTime, @Now) < @DaysOld)) -- without anonymous users who are online or were online less than @DaysOld days ago
		))

	-- Delete room's dependencies
	DELETE [Chat_SupportTakenRoom] WHERE [ChatSupportTakenRoomRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_InitiatedChatRequest] WHERE [InitiatedChatRequestRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_RoomUser] WHERE [ChatRoomUserRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_Notification] WHERE [ChatNotificationRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_Message] WHERE [ChatMessageRoomID] IN (SELECT RoomID FROM @RoomsToDelete);

	-- Delete rooms
	DELETE [Chat_Room] WHERE [ChatRoomID] IN (SELECT RoomID FROM @RoomsToDelete);

	SET @RoomsDeleted = @@ROWCOUNT

	-- Third step: delete inactive anonymous users
	DECLARE @ChatUsersToDelete TABLE (ChatUserID INT);

	-- Find inactive users and store their IDs to table variable
	INSERT @ChatUsersToDelete
	SELECT CU.ChatUserID
	FROM Chat_User AS CU
	WHERE CU.ChatUserUserID IS NULL -- anonymous users only
	AND NOT EXISTS (SELECT ChatMessageID FROM Chat_Message CM WHERE CM.ChatMessageUserID = CU.ChatUserID OR CM.ChatMessageRecipientID = CU.ChatUserID) -- without messages
	AND NOT EXISTS (SELECT ChatOnlineUserID FROM Chat_OnlineUser COU WHERE COU.ChatOnlineUserChatUserID = CU.ChatUserID AND (COU.ChatOnlineUserJoinTime IS NOT NULL OR DATEDIFF(dd, COU.ChatOnlineUserLeaveTime, @Now) < @DaysOld)) -- user is not online and was online more than @DaysOld days ago
	
	-- Delete user's dependencies
	DELETE FROM [Chat_OnlineUser] WHERE [ChatOnlineUserChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_InitiatedChatRequest] WHERE [InitiatedChatRequestInitiatorChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_OnlineSupport] WHERE [ChatOnlineSupportChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_SupportCannedResponse] WHERE [ChatSupportCannedResponseChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_Message] WHERE [ChatMessageRecipientID] IN (SELECT ChatUserID FROM @ChatUsersToDelete) OR [ChatMessageUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_RoomUser] WHERE [ChatRoomUserChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_SupportTakenRoom] WHERE [ChatSupportTakenRoomChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_Notification] WHERE [ChatNotificationReceiverID] IN (SELECT ChatUserID FROM @ChatUsersToDelete) OR [ChatNotificationSenderID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	UPDATE [Chat_Room] SET [ChatRoomCreatedByChatUserID] = NULL WHERE [ChatRoomCreatedByChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)

	-- Delete users
	DELETE FROM [Chat_User] WHERE [ChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)

	SET @UsersDeleted = @@ROWCOUNT

	SELECT @MessagesDeleted AS MessagesDeleted, @RoomsDeleted AS RoomsDeleted, @UsersDeleted AS UsersDeleted
END
GO

-- B6119 - [Marketing automation] - Missing automation actions in ribbon
UPDATE [CMS_Workflow] SET [WorkflowAllowedObjects] = N';om.contact;' WHERE [WorkflowType] = 3
GO

-- B6116 - [Web Analytics] - "mobile devices" section should be under section "visitors" not under "traffic sources"
DECLARE @parentPrefix VARCHAR(450);
DECLARE @parentID VARCHAR(450);

SET @parentID = (SELECT ElementID FROM CMS_UIElement WHERE ElementName = 'Visitors')
SET @parentPrefix = (SELECT ElementIDPath FROM CMS_UIElement WHERE ElementID = @parentID)

UPDATE CMS_UIElement SET ElementParentID = @parentID, ElementOrder = '5', ElementIDPath = @parentPrefix + SUBSTRING(ElementIDPath, LEN(ElementIDPath) - 8, LEN(ElementIDPath)) WHERE ElementParentID <> @parentID AND ElementName = 'crawler'
UPDATE CMS_UIElement SET ElementParentID = @parentID, ElementOrder = '6', ElementIDPath = @parentPrefix + SUBSTRING(ElementIDPath, LEN(ElementIDPath) - 8, LEN(ElementIDPath)) WHERE ElementParentID <> @parentID AND ElementName = 'MobileDevice'

GO

-- B6189 - [Web Analytics] - Settings for enabling web crawler tracking and mobile devices tracking were in wrong category
DECLARE @categoryID VARCHAR(450);
SET @categoryID = (SELECT TOP 1 CategoryID FROM CMS_SettingsCategory WHERE CategoryName = 'CMS.WebAnalytics.Visitors')
UPDATE CMS_SettingsKey SET KeyCategoryID = @categoryID WHERE (KeyName = 'CMSTrackMobileDevices' OR KeyName = 'CMSTrackSearchCrawlers') AND KeyCategoryID <> @categoryID
GO

-- B6239 - [ProjectManagement] - ProjectTaskDescription field missing in ProjectTaskListInfo
ALTER VIEW [View_PM_ProjectTaskStatus_Joined]
AS
SELECT        PM_ProjectTask.ProjectTaskID, PM_ProjectTask.ProjectTaskDisplayName, tblAssignee.FullName AS AssigneeFullName, 
                         tblAssignee.UserName AS AssigneeUserName, tblOwner.FullName AS OwnerFullName, tblOwner.UserName AS OwnerUserName, 
                         PM_ProjectTaskPriority.TaskPriorityDisplayName, PM_ProjectTaskStatus.TaskStatusDisplayName, PM_ProjectTask.ProjectTaskHours, 
                         PM_ProjectTask.ProjectTaskProgress, PM_ProjectTask.ProjectTaskProjectID, PM_ProjectTaskStatus.TaskStatusColor, 
                         PM_ProjectTask.ProjectTaskProjectOrder, PM_ProjectTask.ProjectTaskUserOrder, PM_ProjectTaskStatus.TaskStatusIcon, 
                         PM_ProjectTask.ProjectTaskAssignedToUserID, PM_ProjectTask.ProjectTaskOwnerID, PM_ProjectTask.ProjectTaskDeadline, 
                         PM_ProjectTask.ProjectTaskIsPrivate, PM_Project.ProjectDisplayName, PM_ProjectTaskStatus.TaskStatusIsFinished, 
                         PM_ProjectTaskPriority.TaskPriorityOrder, PM_Project.ProjectSiteID, PM_Project.ProjectOwner, PM_Project.ProjectGroupID, 
                         PM_Project.ProjectAccess, PM_Project.ProjectID, PM_ProjectTask.ProjectTaskDescription
FROM            PM_ProjectTask LEFT OUTER JOIN
                         PM_ProjectTaskStatus ON PM_ProjectTaskStatus.TaskStatusID = PM_ProjectTask.ProjectTaskStatusID LEFT OUTER JOIN
                         PM_ProjectTaskPriority ON PM_ProjectTask.ProjectTaskPriorityID = PM_ProjectTaskPriority.TaskPriorityID LEFT OUTER JOIN
                         PM_Project ON PM_ProjectTask.ProjectTaskProjectID = PM_Project.ProjectID LEFT OUTER JOIN
                         CMS_User AS tblAssignee ON PM_ProjectTask.ProjectTaskAssignedToUserID = tblAssignee.UserID LEFT OUTER JOIN
                         CMS_User AS tblOwner ON PM_ProjectTask.ProjectTaskOwnerID = tblOwner.UserID

GO

-- B6321 [DocumentAlias] - Inssuficion join where clause in select all query (same campaign name in different sites issue)
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 29
BEGIN
	UPDATE CMS_QUERY SET QueryText =
	'SELECT ##TOPN## ##COLUMNS## FROM CMS_DocumentAlias LEFT JOIN Analytics_Campaign ON AliasCampaign = CampaignName AND AliasSiteID = CampaignSiteID WHERE ##WHERE## ORDER BY ##ORDERBY##'
	WHERE QueryName = 'selectall' AND ClassID IN (SELECT ClassID FROM CMS_Class WHERE ClassName='CMS.DocumentAlias')
END
GO

-- B6351 CategoryInfoProvider.GetDocumentCategories(where, orderby, topn) method used badly formed query
UPDATE CMS_Query
SET QueryText = 
'WITH AllData (CategoryID, CategoryDisplayName, CategoryName, CategoryCount, CategoryNamePath, CategoryIDPath, CategoryUserID, CategorySiteID, CategoryParentID)
AS
(
SELECT CMS_Category.CategoryID, CMS_Category.CategoryDisplayName, CMS_Category.CategoryName, count(DocumentID) as CategoryCount, CMS_Category.CategoryNamePath, CMS_Category.CategoryIDPath, CMS_Category.CategoryUserID, CMS_Category.CategorySiteID, CMS_Category.CategoryParentID
FROM CMS_Category INNER JOIN CMS_DocumentCategory ON CMS_Category.CategoryID = CMS_DocumentCategory.CategoryID WHERE DocumentID IN (SELECT DocumentID FROM View_CMS_Tree_Joined WHERE ##WHERE##) 
GROUP BY CMS_Category.CategoryID, CMS_Category.CategoryDisplayName, CMS_Category.CategoryName, CMS_Category.CategoryNamePath, CMS_Category.CategoryIDPath, CMS_Category.CategoryUserID, CMS_Category.CategorySiteID, CMS_Category.CategoryParentID
)

SELECT ##TOPN## CategoryID, CategoryDisplayName, CategoryName, CategoryCount, CategoryNamePath, CategoryIDPath, CategoryUserID, CategorySiteID, CategoryParentID 
FROM AllData AS cats
WHERE NOT EXISTS (SELECT CategoryID FROM AllData WHERE CategoryParentID = cats.CategoryID)
ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectDocumentsCategories' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'cms.category')
GO

-- B6439 [Reporting] - Hourly report does not work
UPDATE Reporting_Report
SET 
	ReportParameters = REPLACE(ReportParameters, 'column="CodeName"', 'column="CodeName" defaultvalue="filedownloads"'),
	ReportLastModified = GETDATE()
WHERE
ReportName = 'filedownloads.hourreport'
AND ReportLastModified = '2012-03-23 11:13:45.000'
GO


-- B6481 - Deadlocks in versioning
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_CMS_ObjectVersionHistory_VersionModifiedByUserID')
BEGIN
CREATE NONCLUSTERED INDEX IX_CMS_ObjectVersionHistory_VersionModifiedByUserID ON CMS_ObjectVersionHistory
(
VersionModifiedByUserID ASC
)
END
GO

--TES-321 Permissions - Report for user not working in Azure
UPDATE CMS_Query
SET QueryText =
'SELECT ##TOPN## Matrix.##COLUMNS##, (CASE WHEN CMS_RolePermission.RoleID IS NULL THEN 0 ELSE 1 END) AS [Allowed] FROM (SELECT CMS_Permission.PermissionID, 
CMS_Permission.PermissionOrder, CMS_Permission.PermissionDisplayName, CMS_Permission.PermissionName, CMS_Permission.ClassID, CMS_Permission.ClassID AS ResourceID,CMS_Permission.PermissionDescription, CMS_Role.RoleID, CMS_Role.Rolename, CMS_Role.RoleDisplayName FROM CMS_Permission, CMS_Role WHERE (CMS_Permission.PermissionDisplayInMatrix = @DisplayInMatrix OR ((@DisplayInMatrix=1) AND (CMS_Permission.PermissionDisplayInMatrix IS NULL))) AND ClassID = @ID AND RoleID IN (SELECT RoleID FROM CMS_Role WHERE ##WHERE## AND ((SiteID IS NULL AND @SiteID =0) OR SiteID = @SiteID)) )
Matrix LEFT JOIN CMS_RolePermission ON (Matrix.PermissionID = CMS_RolePermission.PermissionID AND CMS_RolePermission.RoleID = Matrix.RoleID) ORDER BY ##ORDERBY##' 
WHERE QueryName = N'getClassPermissionMatrix' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'cms.permission')
GO

-- 6487 HIGH VOLUME of FORUM posts with SMART SEARCH issue
UPDATE CMS_Query
SET QueryText = 
'SELECT ##TOPN## Forums_ForumPost.*, ForumSiteID FROM Forums_ForumPost 
LEFT JOIN Forums_Forum ON ForumID = PostForumID 
LEFT JOIN Forums_ForumGroup ON ForumGroupID = Forums_ForumGroup.GroupID 
WHERE Forums_Forum.ForumDocumentID IS NULL AND Forums_ForumGroup.GroupGroupID IS NULL AND PostApproved = 1 AND ##WHERE## 
ORDER BY PostId'
WHERE QueryName = N'getsearchposts' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'Forums.ForumPost')
GO


-- TES-131 Data.com license fix

-- Hide settings keys
UPDATE [CMS_SettingsKey] SET [KeyIsHidden] = 1 WHERE [KeyName] IN ('CMSDataComToken','CMSDataComUsername','CMSDataComPassword');

DECLARE @RESOURCEID INT;
SET @RESOURCEID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceName] = N'CMS.ContactManagement')

-- Add user control
IF NOT EXISTS (SELECT [UserControlCodeName] FROM [CMS_FormUserControl] WHERE [UserControlCodeName] = N'Data.comLogin')
BEGIN
INSERT INTO [CMS_FormUserControl] ([UserControlDisplayName], [UserControlCodeName], [UserControlFileName], [UserControlForText], [UserControlForLongText], [UserControlForInteger], [UserControlForDecimal], [UserControlForDateTime], [UserControlForBoolean], [UserControlForFile], [UserControlShowInBizForms], [UserControlDefaultDataType], [UserControlDefaultDataTypeSize], [UserControlShowInDocumentTypes], [UserControlShowInSystemTables], [UserControlShowInWebParts], [UserControlShowInReports], [UserControlGUID], [UserControlLastModified], [UserControlForGuid], [UserControlShowInCustomTables], [UserControlForVisibility], [UserControlParameters], [UserControlForDocAttachments], [UserControlForLongInteger], [UserControlResourceID], [UserControlType], [UserControlParentID], [UserControlDescription], [UserControlThumbnailGUID], [UserControlPriority], [UserControlIsSystem]) VALUES (N'Data.com login', N'Data.comLogin', N'~/CMSModules/ContactManagement/FormControls/DataCom/DataComLogin.ascx', 1, 0, 0, 0, 0, 0, 0, 0, N'Text', NULL, 0, 0, 0, 0, '937dc500-479d-4058-b11f-fd8bf40969a0', GETDATE(), 0, 0, 0, NULL, 0, 0, @RESOURCEID, 4, NULL, N'', NULL, NULL, NULL)
END

-- Edit workflow action
UPDATE [CMS_WorkflowAction] SET [ActionParameters] = N'<form><field column="DataComUserName" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="150" captionstyle="Hidden" inputcontrolstyle="Hidden" publicfield="false" controlcssclass="Hidden" guid="36d0b719-2b99-40d9-b81e-517905f3ced4" visibility="none" visiblemacro="{%false%}"><settings><controlname>data.comlogin</controlname></settings></field><field column="DataComPassword" columntype="text" fieldtype="CustomUserControl" columnsize="150" captionstyle="hidden" publicfield="false" guid="21102397-74fe-4c5f-99c4-f116aec60238"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="BuyEnabled" fieldcaption="{$datacom.automation.buyenabled$}" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" fielddescription="{$datacom.automation.buyenabled.description$}" publicfield="false" guid="b257e282-44d1-4488-8947-3844b4d18770"><settings><controlname>checkboxcontrol</controlname></settings></field></form>' WHERE [ActionName] = N'Update_from_DataCom';
GO



-- TES-163 - Permission Create missing for upgraded Document types (from v6 to v7)

-- Create table with document type IDs which hasn't CreateSpecific permission
CREATE TABLE #DocumentTypes (RowNum int NOT NULL, [ClassID] int)
INSERT INTO #DocumentTypes(RowNum, [ClassID]) SELECT ROW_NUMBER() OVER(ORDER BY ClassID), ClassID FROM CMS_Class WHERE (ClassIsDocumentType = 1) AND (ClassID NOT IN (SELECT ClassID FROM CMS_Permission WHERE PermissionName = 'CreateSpecific'))

-- Declare variables
DECLARE @MaxRownum INT;
DECLARE @Iter INT;
DECLARE @classID INT;

SET @Iter = (SELECT MIN(RowNum) FROM #DocumentTypes);
SET @MaxRownum = (SELECT MAX(RowNum) FROM #DocumentTypes);

WHILE @Iter <= @MaxRownum
BEGIN
	SET @classID = (SELECT ClassID FROM #DocumentTypes WHERE RowNum = @Iter)
	-- Change display name of existing 'Create' permission
	UPDATE [CMS_Permission] SET [PermissionDisplayName] = '{$permissionnames.createanywhere$}', [PermissionDescription] = '{$permissiondescription.document.createanywhere$}' WHERE [PermissionName] = 'Create' AND [ClassID] = @classID
	-- Create free space for new permission
	UPDATE [CMS_Permission] SET [PermissionOrder] = [PermissionOrder] + 1 WHERE [ClassID] = @classID AND [PermissionOrder] >= 3
	-- Insert missing 'Create' permission
	INSERT INTO [CMS_Permission] ([PermissionDisplayName], [PermissionName], [ClassID], [ResourceID], [PermissionGUID], [PermissionLastModified], [PermissionDescription] ,[PermissionDisplayInMatrix], [PermissionOrder])
		VALUES ('{$permissionnames.create$}', 'CreateSpecific', @classID, NULL, NEWID(), GETDATE(), '{$permissiondescription.document.create$}', 1, 3)
		
	SET @Iter = @Iter + 1;
END

DROP TABLE #DocumentTypes

GO

-- TES-190, TES-453 - Multiple newsletters sending (TES-130 Replaced)
GO
ALTER PROCEDURE [Proc_Newsletter_Emails_CreateMails]
@NewsletterIssueID int,
@NewsletterID int,
@SiteID int,
@MonitoringEnabled bit,
@BounceLimit int
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRANSACTION
		
IF (@MonitoringEnabled = 0)
BEGIN
	SET @BounceLimit = 0
END

-- Remove temporary table if exists
IF OBJECT_ID('tempdb..#NewsletterEmailsTempTable') IS NOT NULL
BEGIN
	DROP TABLE #NewsletterEmailsTempTable;
END;

-- Create temporary table
CREATE TABLE #NewsletterEmailsTempTable 
(
	EmailID INT IDENTITY(1,1),
	EmailNewsletterIssueID INT,
	EmailSubscriberID INT,
	EmailSiteID INT,
	EmailSending INT,
	EmailGUID uniqueidentifier,
	EmailUserID INT,
	EmailAddress NVARCHAR(200) COLLATE database_default
);


-- Create newsletter email queue items for approved and active classic subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailAddress)
	SELECT Subscription.SubscriberID, Subscriber.SubscriberEmail
	FROM Newsletter_SubscriberNewsletter AS Subscription
		INNER JOIN
		Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID
	WHERE (NewsletterID = @NewsletterID) AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType IS NULL) AND (Subscriber.SubscriberBounces IS NULL OR (@BounceLimit <= 0 AND Subscriber.SubscriberBounces < 2147483647) OR Subscriber.SubscriberBounces < @BounceLimit)
	ORDER BY Subscription.SubscriberID
   
-- Create newsletter email queue items for approved and active user subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailAddress)
	SELECT Subscription.SubscriberID, CMS_User.Email
	FROM (Newsletter_SubscriberNewsletter AS Subscription INNER JOIN Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID)
		LEFT OUTER JOIN CMS_User ON Subscriber.SubscriberRelatedID = CMS_User.UserID
	WHERE NewsletterID = @NewsletterID AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType = 'cms.user') AND (Subscriber.SubscriberBounces IS NULL OR (@BounceLimit <= 0 AND Subscriber.SubscriberBounces < 2147483647) OR Subscriber.SubscriberBounces < @BounceLimit) AND
		NOT (CMS_User.Email IS NULL OR CMS_User.Email = '')
	ORDER BY Subscription.SubscriberID

-- Create newsletter email queue items for approved and active role subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailUserID, EmailAddress)
	SELECT Subscription.SubscriberID, UserInfo.UserID, UserInfo.Email
	FROM (Newsletter_SubscriberNewsletter AS Subscription INNER JOIN Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID)
		LEFT OUTER JOIN
		View_CMS_UserSettingsRole_Joined AS UserInfo ON Subscriber.SubscriberRelatedID = UserInfo.RoleID
	WHERE NewsletterID = @NewsletterID AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType = 'cms.role') AND (UserInfo.UserBounces IS NULL OR (@BounceLimit <= 0 AND UserInfo.UserBounces < 2147483647) OR UserInfo.UserBounces < @BounceLimit) AND
		NOT (UserInfo.Email IS NULL OR UserInfo.Email = '')
	ORDER BY Subscription.SubscriberID

-- Remove duplicates
DELETE #NewsletterEmailsTempTable 
FROM #NewsletterEmailsTempTable
LEFT OUTER JOIN (
	SELECT MIN(EmailID) as EmailID, EmailAddress
	FROM #NewsletterEmailsTempTable 
	GROUP BY EmailAddress
) as KeepRecords ON
	#NewsletterEmailsTempTable.EmailID = KeepRecords.EmailID
WHERE KeepRecords.EmailID IS NULL

-- Insert data from temporary table to Newsletter_Emails without duplicates 
INSERT INTO Newsletter_Emails (EmailNewsletterIssueID, EmailSubscriberID, EmailSiteID, EmailSending, EmailGUID, EmailUserID, EmailAddress)
		SELECT @NewsletterIssueID, EmailSubscriberID, @SiteID, 1, NEWID(), EmailUserID, EmailAddress 
		FROM #NewsletterEmailsTempTable 
		WHERE NOT EXISTS (SELECT EmailAddress FROM Newsletter_Emails WHERE EmailAddress = #NewsletterEmailsTempTable.EmailAddress AND EmailNewsletterIssueID = @NewsletterIssueID)

-- Reset sending status so the sending may start	
UPDATE Newsletter_Emails SET EmailSending = NULL WHERE EmailNewsletterIssueID = @NewsletterIssueID
COMMIT TRANSACTION;
END
GO

-- TES-199 UltimateV7 license fix for sample sites

UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'48f74a3f-3447-409e-aeec-9aa402a764bc' AND [WebTemplateLastModified] = N'20120821 09:32:49' AND [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'C;E;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'23cdbe82-802b-4c38-82cd-95f510e2876d' AND [WebTemplateLastModified] = N'20120820 13:14:58' AND [WebTemplateLicenses] = N'C;E;U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'f2022396-1508-42c3-8d0f-9a41d7c7be57' AND [WebTemplateLastModified] = N'20120820 13:16:40' AND [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'872ccfbc-3b4a-4c91-b99d-a5b15bcea3c3' AND [WebTemplateLastModified] = N'20120914 12:38:15' AND [WebTemplateLicenses] = N'U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'B;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'7cab38db-8c2d-4bd6-95b9-d451ac08fbab' AND [WebTemplateLastModified] = N'20120820 14:14:00' AND [WebTemplateLicenses] = N'B;U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'1925540f-4765-4159-8f1a-cd8c28f35ad9' AND [WebTemplateLastModified] = N'20110714 18:18:41' AND [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;'
UPDATE [CMS_WebTemplate] SET [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;V;', [WebTemplateLastModified] = GETDATE() WHERE [WebTemplateGUID] = N'762b1a36-8d31-4df4-beb8-cfe242703620' AND [WebTemplateLastModified] = N'20110714 18:18:36' AND [WebTemplateLicenses] = N'F;S;B;N;C;P;R;E;U;X;'
GO


-- TES - 230 - Attachments under workflow can have same name in some cases

ALTER PROCEDURE [Proc_CMS_Attachment_SelectUniqueFileName]
	@AttachmentFormGUID uniqueidentifier,
	@AttachmentName nvarchar(255),
	@AttachmentExtension nvarchar(50),
	@CurrentAttachmentID int,
	@SelectFromVersionHistory bit,
	@AttachmentDocumentID int
AS
BEGIN
	IF @AttachmentFormGUID IS NOT NULL
		SELECT DISTINCT AttachmentID, AttachmentName FROM CMS_Attachment WHERE AttachmentFormGUID = @AttachmentFormGUID AND AttachmentName = @AttachmentName AND AttachmentExtension = @AttachmentExtension AND AttachmentID <> @CurrentAttachmentID AND AttachmentDocumentID IS NULL
	ELSE	
		IF @SelectFromVersionHistory = 1
			BEGIN
				DECLARE @VersionHistoryID int;
				SET @VersionHistoryID = (SELECT TOP 1 VersionHistoryID FROM CMS_AttachmentHistory INNER JOIN CMS_VersionAttachment ON CMS_AttachmentHistory.AttachmentHistoryID = CMS_VersionAttachment.AttachmentHistoryID WHERE CMS_AttachmentHistory.AttachmentHistoryID = @CurrentAttachmentID ORDER BY VersionHistoryID DESC);
				SELECT DISTINCT CMS_VersionAttachment.AttachmentHistoryID, AttachmentName FROM CMS_AttachmentHistory INNER JOIN CMS_VersionAttachment ON CMS_AttachmentHistory.AttachmentHistoryID = CMS_VersionAttachment.AttachmentHistoryID WHERE AttachmentName = @AttachmentName AND AttachmentExtension = @AttachmentExtension AND CMS_AttachmentHistory.AttachmentHistoryID <> @CurrentAttachmentID AND AttachmentDocumentID = @AttachmentDocumentID AND CMS_VersionAttachment.VersionHistoryID=@VersionHistoryID
			END
		ELSE
			SELECT DISTINCT AttachmentID, AttachmentName FROM CMS_Attachment WHERE AttachmentName = @AttachmentName AND AttachmentExtension = @AttachmentExtension AND AttachmentID <> @CurrentAttachmentID AND AttachmentDocumentID = @AttachmentDocumentID
END

GO

-- TES-285  - A "Conversion name" resource string was used for conversion value field in custom registration webpart properties.
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 60
BEGIN
		UPDATE CMS_WebPart SET WebPartProperties = REPLACE(WebPartProperties, N'<field column="ConversionValue" fieldcaption="Conversion name"', N'<field column="ConversionValue" fieldcaption="{$om.trackconversionvalue$}"') WHERE WebPartName = N'CustomRegistrationForm'
END
GO

-- TES-294  - Update to banner reporting queries

GO

UPDATE [Reporting_ReportGraph]
SET GraphQuery='--DECLARE @BannerId INT;
--DECLARE @FromDate DATETIME;
--DECLARE @ToDate DATETIME;
--SET @BannerId = 8;
--SET @FromDate = ''2/9/2012 6:14:30 PM'';
--SET @ToDate = ''4/9/2012 6:14:30 PM'';
SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''day'');
SELECT 
    [Date], T3.clicks as ''{$banner.clicks$}'', T3.hits as ''{$banner.hits$}''
FROM Func_Analytics_EnsureDates(@FromDate,@ToDate,''day'') AS Dates
LEFT JOIN
(
	SELECT T2.HitsStartTime, T2.hits, T1.clicks
	FROM
		(SELECT HitsStartTime, HitsCount AS clicks
		FROM Analytics_Statistics
		INNER JOIN Analytics_DayHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerclick'')
		) AS T1
	FULL JOIN 
		(SELECT HitsStartTime, HitsCount AS hits
		FROM Analytics_Statistics
		INNER JOIN Analytics_DayHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerhit'')
		) AS T2
	ON T1.HitsStartTime = T2.HitsStartTime
 ) AS T3
ON [Date] = HitsStartTime' WHERE GraphName = 'GraphHitsClicks' AND GraphReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] where ReportName = 'bannerhitsclicks.dayreport');

UPDATE [Reporting_ReportGraph]
SET GraphQuery='--DECLARE @BannerId INT;
--DECLARE @FromDate DATETIME;
--DECLARE @ToDate DATETIME;
--SET @BannerId = 8;
--SET @FromDate = ''2/9/2012 6:14:30 PM'';
--SET @ToDate = ''4/9/2012 6:14:30 PM'';
SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''month'');
SELECT 
    [Date], T3.clicks as ''{$banner.clicks$}'', T3.hits as ''{$banner.hits$}''
FROM Func_Analytics_EnsureDates(@FromDate,@ToDate,''month'') AS Dates
LEFT JOIN
(
	SELECT T2.HitsStartTime, T2.hits, T1.clicks
	FROM
		(SELECT HitsStartTime, HitsCount AS clicks
		FROM Analytics_Statistics
		INNER JOIN Analytics_MonthHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerclick'')
		) AS T1
	FULL JOIN 
		(SELECT HitsStartTime, HitsCount AS hits
		FROM Analytics_Statistics
		INNER JOIN Analytics_MonthHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerhit'')
		) AS T2
	ON T1.HitsStartTime = T2.HitsStartTime
 ) AS T3
ON [Date] = HitsStartTime' WHERE GraphName = 'GraphHitsClicks' AND GraphReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] where ReportName = 'bannerhitsclicks.monthreport');

UPDATE [Reporting_ReportGraph]
SET GraphQuery='--DECLARE @BannerId INT;
--DECLARE @FromDate DATETIME;
--DECLARE @ToDate DATETIME;
--SET @BannerId = 8;
--SET @FromDate = ''2/9/2012 6:14:30 PM'';
--SET @ToDate = ''4/9/2012 6:14:30 PM'';
SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''hour'');
SELECT 
    [Date], T3.clicks as ''{$banner.clicks$}'', T3.hits as ''{$banner.hits$}''
FROM Func_Analytics_EnsureDates(@FromDate,@ToDate,''hour'') AS Dates
LEFT JOIN
(
	SELECT T2.HitsStartTime, T2.hits, T1.clicks
	FROM
		(SELECT HitsStartTime, HitsCount AS clicks
		FROM Analytics_Statistics
		INNER JOIN Analytics_HourHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerclick'')
		) AS T1
	FULL JOIN 
		(SELECT HitsStartTime, HitsCount AS hits
		FROM Analytics_Statistics
		INNER JOIN Analytics_HourHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerhit'')
		) AS T2
	ON T1.HitsStartTime = T2.HitsStartTime
 ) AS T3
ON [Date] = HitsStartTime' WHERE GraphName = 'GraphHitsClicks' AND GraphReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] where ReportName = 'bannerhitsclicks.hourreport');

UPDATE [Reporting_ReportGraph]
SET GraphQuery='--DECLARE @BannerId INT;
--DECLARE @FromDate DATETIME;
--DECLARE @ToDate DATETIME;
--SET @BannerId = 8;
--SET @FromDate = ''2/9/2012 6:14:30 PM'';
--SET @ToDate = ''4/9/2012 6:14:30 PM'';
SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''week'');
SELECT 
    [Date], T3.clicks as ''{$banner.clicks$}'', T3.hits as ''{$banner.hits$}''
FROM Func_Analytics_EnsureDates(@FromDate,@ToDate,''week'') AS Dates
LEFT JOIN
(
	SELECT T2.HitsStartTime, T2.hits, T1.clicks
	FROM
		(SELECT HitsStartTime, HitsCount AS clicks
		FROM Analytics_Statistics
		INNER JOIN Analytics_WeekHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerclick'')
		) AS T1
	FULL JOIN 
		(SELECT HitsStartTime, HitsCount AS hits
		FROM Analytics_Statistics
		INNER JOIN Analytics_WeekHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerhit'')
		) AS T2
	ON T1.HitsStartTime = T2.HitsStartTime
 ) AS T3
ON [Date] = HitsStartTime' WHERE GraphName = 'GraphHitsClicks' AND GraphReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] where ReportName = 'bannerhitsclicks.weekreport');

UPDATE [Reporting_ReportGraph]
SET GraphQuery='--DECLARE @BannerId INT;
--DECLARE @FromDate DATETIME;
--DECLARE @ToDate DATETIME;
--SET @BannerId = 8;
--SET @FromDate = ''2/9/2012 6:14:30 PM'';
--SET @ToDate = ''4/9/2012 6:14:30 PM'';
SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''year'');
SELECT 
    YEAR([Date]) StartDate, T3.clicks as ''{$banner.clicks$}'', T3.hits as ''{$banner.hits$}''
FROM Func_Analytics_EnsureDates(@FromDate,@ToDate,''year'') AS Dates
LEFT JOIN
(
	SELECT T2.HitsStartTime, T2.hits, T1.clicks
	FROM
		(SELECT HitsStartTime, HitsCount AS clicks
		FROM Analytics_Statistics
		INNER JOIN Analytics_YearHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerclick'')
		) AS T1
	FULL JOIN 
		(SELECT HitsStartTime, HitsCount AS hits
		FROM Analytics_Statistics
		INNER JOIN Analytics_YearHits ON HitsStatisticsID = Analytics_Statistics.StatisticsID
		WHERE (Analytics_Statistics.StatisticsObjectID = @BannerID) 
			AND (StatisticsCode = ''bannerhit'')
		) AS T2
	ON T1.HitsStartTime = T2.HitsStartTime
 ) AS T3
ON [Date] = HitsStartTime' WHERE GraphName = 'GraphHitsClicks' AND GraphReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] where ReportName = 'bannerhitsclicks.yearreport');

GO

-- TES - 362 - [Documents] - Timeouts when creating new culture version
GO

ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10)
AS
BEGIN
 DECLARE @parents TABLE (
   NodeParentID int,
   DocumentCulture nvarchar(10)
 );

 INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID
  
 DECLARE @nodeParentId int;
 DECLARE @parentDocumentCulture nvarchar(10);
 DECLARE @parentUseNamePathForUrlPath bit;
 DECLARE @parentDocumentUrlPath nvarchar(450);
 DECLARE @parentDocumentNamePath nvarchar(1500);

 DECLARE @parentCursor CURSOR;
 SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
  
 OPEN @parentCursor
 FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
 WHILE @@FETCH_STATUS = 0
 BEGIN

 DECLARE @nodesUpdated bit;

 SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath FROM
  (SELECT TOP 1 DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID, NodeLinkedNodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
  FROM View_CMS_Tree_Joined WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
  ORDER BY Priority ASC) TopParentPath;

  UPDATE CMS_Document SET DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND @parentDocumentUrlPath <> '' AND  DocumentUrlPath <> '' THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END) WHERE DocumentNodeID IN (SELECT NodeID FROM CMS_Tree WHERE NodeParentID = @nodeParentId) AND DocumentCulture = @parentDocumentCulture
  IF @@ROWCOUNT <> 0
  BEGIN
   SET @nodesUpdated = 1;
  END

  FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
 END

 CLOSE @parentCursor;
 DEALLOCATE @parentCursor;

 IF @nodesUpdated = 1
 BEGIN
  SET @NodeLevel = @NodeLevel + 1;
  EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode;
 END
END

GO

-- TES - 376 - Default analytics reports, error in page view year report

UPDATE [Reporting_ReportTable] 
SET [TableQuery] = 
'DECLARE @PaveViews TABLE
(
  DocumentNamePath NVARCHAR(500),
  ObjectID INT,
  Pageviews INT,
  Percents DECIMAL(10,2),
  Average INT  
)

DECLARE @Sum DECIMAL;

SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''year'');
SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''year'');

SELECT @Sum =   
  SUM(HitsCount)
  FROM Analytics_Statistics
  INNER JOIN Analytics_YearHits ON Analytics_YearHits.HitsStatisticsID = Analytics_Statistics.StatisticsID
  LEFT JOIN View_CMS_Tree_Joined ON View_CMS_Tree_Joined.NodeID = Analytics_Statistics.StatisticsObjectID  AND StatisticsObjectCulture = DocumentCulture
  WHERE (StatisticsSiteID = @CMSContextCurrentSiteID)
  AND (StatisticsCode=@CodeName)
  AND (HitsStartTime >= @FromDate)
 AND (HitsEndTime <= @ToDate)

INSERT INTO @PaveViews (DocumentNamePath,objectID,pageViews,percents)
SELECT TOP 100
 CASE
  WHEN DocumentNamePath LIKE '''' OR DocumentNamePath IS NULL THEN StatisticsObjectName
  ELSE DocumentNamePath
 END , StatisticsObjectID, SUM(HitsCount), (SUM(HitsCount)/@Sum)*100
 FROM Analytics_Statistics
 INNER JOIN Analytics_YearHits ON Analytics_YearHits.HitsStatisticsID = Analytics_Statistics.StatisticsID
 LEFT JOIN View_CMS_Tree_Joined ON Analytics_Statistics.StatisticsObjectID = View_CMS_Tree_Joined.NodeID AND StatisticsObjectCulture = DocumentCulture
 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)
 AND (StatisticsCode=@CodeName)
 GROUP BY DocumentNamePath, StatisticsObjectName,StatisticsObjectID
 ORDER BY SUM(HitsCount) DESC
 
 UPDATE @PaveViews SET Average = (SELECT SUM(HitsValue)/SUM(HitsCount) FROM Analytics_YearHits JOIN
      Analytics_Statistics ON HitsStatisticsID = StatisticsID
      WHERE HitsStartTime >= @FromDate AND HitsEndTime <= @ToDate AND StatisticsObjectID = objectID
        AND StatisticsCode =''avgtimeonpage'' AND StatisticsSiteID = @CMSContextCurrentSiteID
       )
 
 SELECT DocumentNamePath AS ''{$reports_pageviews_Year.path_header$}'',pageviews AS  ''{$reports_pageviews_Year.hits_header$}'',
      CAST (Percents AS NVARCHAR(10))+''%'' AS ''{$reports_pageviews.percent_header$}'', ISNULL(CONVERT(varchar, DATEADD(s, average, 0), 108),''00:00:00'') AS ''{$reports_pageviews.average$}''
  
   FROM @PaveViews ORDER BY PageViews DESC'
WHERE [Reporting_ReportTable].[TableReportID] 
  = (SELECT [ReportID] FROM [Reporting_Report] WHERE [Reporting_Report].[ReportName] = 'pageviews.yearreport')

GO

-- TES - 377 - Some of the On-line marketing features did not work correctly when you upgraded from version 6.0 to 7.0 and separated database. 

 UPDATE [CMS_Query]
SET [QueryConnectionString] = 'CMSOMConnectionString'
FROM [CMS_Query] INNER JOIN [CMS_Class] ON [CMS_Query].[ClassID] = [CMS_Class].[ClassID]
WHERE 
	([CMS_Class].[ClassConnectionString] = 'CMSOMConnectionString'
		AND ([QueryConnectionString] IS NULL OR [QueryConnectionString] = '')
		AND [QueryName] != 'removeotherdependencies')
	OR [QueryName] = 'removeomdependencies';

GO

-- TES-381 - Function caused errors in specific reports - uncommented part causing the troubles

ALTER FUNCTION [Func_Analytics_EnsureDates]
        (
        @StartDate DATETIME,
        @EndDate   DATETIME,
        @DayPart   VARCHAR(5) -- support 'day','month','week','year','hour', default 'day'
        )
RETURNS @rtnTable TABLE
(
	[DATE] datetime PRIMARY KEY
)
AS
BEGIN
	IF (@DayPart = 'year') BEGIN
		IF (@EndDate IS NULL)
		BEGIN		
			SET @EndDate = (SELECT TOP 1 HitsStartTime FROM Analytics_YearHits ORDER BY HitsStartTime DESC)
		END;
		IF (@StartDate IS NULL)
		BEGIN
			SET @StartDate =  (SELECT TOP 1 HitsStartTime FROM Analytics_YearHits ORDER BY HitsStartTime ASC)
		END;			
	END;
	IF (@DayPart = 'month') BEGIN
		IF (@EndDate IS NULL)
		BEGIN		
			SET @EndDate = (SELECT TOP 1 HitsStartTime FROM Analytics_MonthHits ORDER BY HitsStartTime DESC)
		END;
		IF (@StartDate IS NULL)
		BEGIN
			SET @StartDate =  (SELECT TOP 1 HitsStartTime FROM Analytics_MonthHits ORDER BY HitsStartTime ASC)
		END;			
	END;
	IF (@DayPart = 'week') BEGIN
		IF (@EndDate IS NULL)
		BEGIN		
			SET @EndDate = (SELECT TOP 1 HitsStartTime FROM Analytics_WeekHits ORDER BY HitsStartTime DESC)
		END;
		IF (@StartDate IS NULL)
		BEGIN
			SET @StartDate =  (SELECT TOP 1 HitsStartTime FROM Analytics_WeekHits ORDER BY HitsStartTime ASC)
		END;			
	END;
	IF (@DayPart = 'day') BEGIN
		IF (@EndDate IS NULL)
		BEGIN		
			SET @EndDate = (SELECT TOP 1 HitsStartTime FROM Analytics_DayHits ORDER BY HitsStartTime DESC)
		END;
		IF (@StartDate IS NULL)
		BEGIN
			SET @StartDate =  (SELECT TOP 1 HitsStartTime FROM Analytics_DayHits ORDER BY HitsStartTime ASC)
		END;			
	END;
	IF (@DayPart = 'hour') BEGIN
		IF (@EndDate IS NULL)
		BEGIN		
			SET @EndDate = (SELECT TOP 1 HitsStartTime FROM Analytics_HourHits ORDER BY HitsStartTime DESC)
		END;
		IF (@StartDate IS NULL)
		BEGIN
			SET @StartDate =  (SELECT TOP 1 HitsStartTime FROM Analytics_HourHits ORDER BY HitsStartTime ASC)
		END;			
	END;				
	
	WITH dateTable AS
	(
		SELECT TOP (
			CASE @DayPart 
				WHEN 'day'   THEN DATEDIFF(dd,@StartDate,@EndDate)+1
				WHEN 'month' THEN DATEDIFF(mm,@StartDate,@EndDate)+1
				WHEN 'year'  THEN DATEDIFF(yy,@StartDate,@EndDate)+1
				WHEN 'hour'  THEN DATEDIFF(hh,@StartDate,@EndDate)+1
				WHEN 'week'  THEN DATEDIFF(ww,@StartDate,@EndDate)+1
			END  
		)
		ROW_NUMBER() OVER (ORDER BY GetDate())-1 AS N
		FROM sys.All_Columns Sc1
		CROSS JOIN sys.All_Columns Sc2
    )
    INSERT INTO @rtnTable
    SELECT CASE @DayPart 
		WHEN 'day'   THEN DATEADD(dd,t.N,@StartDate)
		WHEN 'month' THEN DATEADD(mm,t.N,@StartDate)
		WHEN 'year'  THEN DATEADD(yy,t.N,@StartDate)
		WHEN 'hour'  THEN DATEADD(hh,t.N,@StartDate)
		WHEN 'week'  THEN DATEADD(ww,t.N,@StartDate)
	END AS DATE
    FROM dateTable t
    
    RETURN
END

GO

-- TES-412 - Campaigns reports did not work correctly when using SQL Azure (unsupported statement SELECT INTO was used) - 39 instances found
-- First pattern:
UPDATE Reporting_ReportGraph
SET GraphQuery = REPLACE(GraphQuery, 'SELECT [Date] AS StartTime ,T1.Hits,StatisticsObjectCulture AS Name INTO #AnalyticsTempTable', 
'CREATE TABLE #AnalyticsTempTable (
	StartTime DATETIME,  
	Hits DECIMAL(15,2),
	Name NVARCHAR(300) COLLATE database_default
);

-- SELECT INTO statement cannot be used, because it is not supported by Azure SQL
INSERT INTO #AnalyticsTempTable
SELECT [Date] AS StartTime, T1.Hits, StatisticsObjectCulture AS Name');

GO

-- Second pattern:
UPDATE Reporting_ReportGraph
SET GraphQuery = REPLACE(GraphQuery, 'SELECT [Date] AS StartTime ,T1.Hits,StatisticsObjectName AS Name INTO #AnalyticsTempTable', 
'CREATE TABLE #AnalyticsTempTable (
    StartTime DATETIME,  
    Hits DECIMAL(15,2),
    Name NVARCHAR(300) COLLATE database_default
);

-- SELECT INTO statement cannot be used, because it is not supported by Azure SQL
INSERT INTO #AnalyticsTempTable
SELECT [Date] AS StartTime, T1.Hits, StatisticsObjectName AS Name');

GO

-- Third pattern:
UPDATE Reporting_ReportGraph
SET GraphQuery = REPLACE(GraphQuery, 'SELECT [Date] AS StartTime ,T1.Hits,T1.ConversionDisplayName AS Name INTO #AnalyticsTempTable', 
'CREATE TABLE #AnalyticsTempTable (
    StartTime DATETIME,  
    Hits DECIMAL(15,2),
    Name NVARCHAR(300) COLLATE database_default
);

-- SELECT INTO statement cannot be used, because it is not supported by Azure SQL
INSERT INTO #AnalyticsTempTable
SELECT [Date] AS StartTime ,T1.Hits,T1.ConversionDisplayName AS Name');

GO

-- TES-415 - Timeout issue when synchronizing root document while having too many documents in the content tree.
ALTER PROCEDURE [Proc_CMS_ACL_RemoveACLID] 
	@ACLIDs nvarchar(450),
	@SiteID int, 
	@NodeAliasPath nvarchar(450)
	
AS
BEGIN
	
	DECLARE @ACLInheritedACLs nvarchar(450);
	DECLARE @ACL int;
	DECLARE @ACLID nvarchar(15);
	DECLARE @InheritedACLsLength int;
	DECLARE @SplitChar char;
	DECLARE @Pos int;
	DECLARE @NewPos int;
	
	DECLARE @aclCursor CURSOR;
	SET @aclCursor = CURSOR FOR SELECT ACLInheritedACLs,ACLID FROM CMS_ACL WHERE CMS_ACL.ACLID IN (SELECT DISTINCT CMS_Tree.NodeACLID FROM CMS_Tree INNER JOIN CMS_ACL ON CMS_ACL.ACLID = CMS_Tree.NodeACLID WHERE ACLInheritedACLs <> '' AND NodeSiteID = @SiteID AND NodeAliasPath LIKE @NodeAliasPath)
	SET @SplitChar = ','
	SET @ACLIDs = ',' + @ACLIDs + ','

OPEN @aclCursor

FETCH NEXT FROM @aclCursor INTO @ACLInheritedACLs, @ACL

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Pos = 1
	WHILE(@Pos IS NOT NULL AND @Pos != 0)
	BEGIN
		SET @NewPos = CHARINDEX(@SplitChar,@ACLIDs,@Pos)
		IF (@NewPos IS NOT NULL AND @NewPos != 0)
		BEGIN
			SET @ACLID = SUBSTRING(@ACLIDs,@Pos,@NewPos - @Pos)
			SET @ACLInheritedACLs = REPLACE(',' + @ACLInheritedACLs + ',', ',' +  @ACLID + ',', ',')
			SET @InheritedACLsLength = LEN(@ACLInheritedACLs)
			IF @InheritedACLsLength > 1
			BEGIN
				SET @ACLInheritedACLs = SUBSTRING(@ACLInheritedACLs, 2,@InheritedACLsLength - 2)
			END
			ELSE
			BEGIN
				SET @ACLInheritedACLs = ''
			END
			SET @Pos = @NewPos + 1			
		END
		ELSE
			SET @Pos = 0
    END
    UPDATE CMS_ACL SET ACLInheritedACLs = @ACLInheritedACLs WHERE ACLID = @ACL

    FETCH NEXT FROM @aclCursor INTO @ACLInheritedACLs, @ACL
END

CLOSE @aclCursor
DEALLOCATE @aclCursor
		
END

GO

-- TES-422 - SQL error in Traffic -> Crawlers table report. Undeclared scalar variable @CodeName replaced by constant
UPDATE [ReportTable] SET [ReportTable].[TableQuery] = REPLACE([ReportTable].[TableQuery], '@CodeName', '''referringsite_search''') FROM [Reporting_ReportTable] [ReportTable]
INNER JOIN [Reporting_Report] ON [Reporting_Report].[ReportID] = [ReportTable].[TableReportID]
WHERE [Reporting_Report].[ReportName] = 'pagereports.Traffic' AND [ReportTable].[TableName] = 'Crawlers'

GO

-- TES-492 - Fix e-product SKU option type for export - replace 'ecommerce.sku' to 'ecommerce.skuoption'
UPDATE CMS_MetaFile
SET MetaFileObjectType = 'ecommerce.skuoption'
WHERE MetaFileObjectID IN (SELECT SKUID FROM COM_SKU WHERE SKUOptionCategoryID IS NOT NULL) AND MetaFileObjectType = 'ecommerce.sku'

GO

-- TES-542 - When renaming document the children DoucmentURLPath is incorrectly generated and document aliases were not created for children in non-default culture when settings 'Remember original URLs when moving documents' and 'Use name path for URL path' were used
GO
ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10),
 @GenerateAliases bit
AS
BEGIN
	DECLARE @parents TABLE (
		NodeParentID int,
		DocumentCulture nvarchar(10)
	);

	-- Get all parents
	INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID
	
	DECLARE @nodeParentId int;
	DECLARE @parentDocumentCulture nvarchar(10);

	DECLARE @parentUseNamePathForUrlPath bit;
	DECLARE @parentDocumentUrlPath nvarchar(450);
	DECLARE @parentDocumentNamePath nvarchar(1500);
	  
	DECLARE @documentUseNamePathForUrlPath bit;

	-- Flag that indicates if procedure should be proceed another level
	DECLARE @updateChildren bit;

	DECLARE @parentCursor CURSOR;
	SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
	
	OPEN @parentCursor
	FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Temporary table for nodes
		DECLARE @nodes TABLE (
		NodeID int,
		DocumentCulture nvarchar(10),
		DocumentURLPath nvarchar(450),
		NodeLinkedNodeID int,
		DocumentUseNamePathForUrlPath bit
		);

		-- Get parent document URL path and name path
		SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath FROM
			(SELECT TOP 1 NodeLinkedNodeID, DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID, NodeLinkedNodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
			FROM View_CMS_Tree_Joined WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
			ORDER BY Priority ASC) TopParentPath;
    
		
		IF (@GenerateAliases = 1)
		BEGIN
			-- Get all children with old values
			INSERT INTO @nodes 
				SELECT NodeID, DocumentCulture, DocumentURLPath, NodeLinkedNodeID, DocumentUseNamePathForUrlPath
				FROM View_CMS_Tree_Joined 
				WHERE NodeParentID = @nodeParentId;
		END
				
		-- Update URL path and name path in the parent node culture
		UPDATE CMS_Document SET 
			DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, 
			DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND @parentDocumentUrlPath <> '' AND  DocumentUrlPath <> '' THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
			WHERE DocumentNodeID IN (SELECT NodeID 
									FROM CMS_Tree 
									WHERE NodeParentID = @nodeParentId) AND DocumentCulture = @parentDocumentCulture
		
		IF @@ROWCOUNT <> 0
		BEGIN
			SET @updateChildren = 1;
		END

		IF (@GenerateAliases = 1)
		BEGIN
			DECLARE @newDocumentURLPath nvarchar(450);
			DECLARE @nodeDocumentUrlPath nvarchar(450);
			DECLARE @nodeDocumentCulture nvarchar(10);
			DECLARE @nodeLinkedNodeId int;
			DECLARE @nodeId int;

			DECLARE @nodesCursor CURSOR;
			SET @nodesCursor = CURSOR FOR SELECT NodeID, DocumentCulture, DocumentURLPath, NodeLinkedNodeID, DocumentUseNamePathForUrlPath FROM @nodes;
 
			OPEN @nodesCursor
			FETCH NEXT FROM @nodesCursor INTO @nodeId, @nodeDocumentCulture, @nodeDocumentUrlPath, @nodeLinkedNodeId, @documentUseNamePathForUrlPath
			WHILE @@FETCH_STATUS = 0
			BEGIN

				-- Create new document URL path to check that is different than before
				SET @newDocumentURLPath = CASE WHEN @documentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath,'') != '') AND  (ISNULL(@nodeDocumentUrlPath,'') != '') 
											THEN @parentDocumentUrlPath + '/' + RIGHT(@nodeDocumentUrlPath, CHARINDEX('/', REVERSE(@nodeDocumentUrlPath)) - 1) 
											ELSE @nodeDocumentUrlPath END;
			
				-- Generate aliases only for non-linked nodes on the current culture with DocumentURLPath specified
				IF (@newDocumentURLPath != @nodeDocumentUrlPath) AND (@nodeLinkedNodeId IS NULL) AND (ISNULL(@nodeDocumentUrlPath,'') != '') AND (ISNULL(@parentDocumentUrlPath,'') != '')
				BEGIN
					-- Check if same alias doesn't exist and doesn't exist document with same DocumentURLPath
					IF NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = @nodeDocumentUrlPath AND AliasNodeID = @nodeId AND (AliasCulture = @nodeDocumentCulture OR ISNULL(AliasCulture, '') = '')) AND
					NOT EXISTS (SELECT DocumentID FROM CMS_Document WHERE DocumentURLpath = @nodeDocumentUrlPath AND DocumentNodeID = @nodeId AND DocumentCulture = @nodeDocumentCulture)
					BEGIN
						INSERT INTO CMS_DocumentAlias (AliasNodeID, AliasCulture, AliasURLPath, AliasExtensions, AliasCampaign, AliasWildcardRule, AliasPriority, AliasGUID, AliasLastModified, AliasSiteID)
						VALUES (@nodeId, @nodeDocumentCulture, @nodeDocumentUrlPath, '', '', '', 1, NEWID(), GETDATE(), @SiteID);
					END
				END

				FETCH NEXT FROM @nodesCursor INTO @nodeId, @nodeDocumentCulture, @nodeDocumentURLPath, @nodeLinkedNodeId, @documentUseNamePathForUrlPath
			END

			CLOSE @nodesCursor;
			DEALLOCATE @nodesCursor;
		END
					
		FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	END
	
	CLOSE @parentCursor;
	DEALLOCATE @parentCursor;

	IF @updateChildren = 1
	BEGIN
		-- Go to next level
		SET @NodeLevel = @NodeLevel + 1;
		EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode, @GenerateAliases;															
	END
END
GO


-- TES-552 - Language selection web part cache was not dependent on query string parameters
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 93
BEGIN
	-- Correct 'Language selection' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form><category name="Layout" visible="True" /><field column="DisplayLayout" fieldcaption="Display layout" visible="true" defaultvalue="horizontal" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="50" fielddescription="Determines the orientation of the list of language selection links. Possible options are horizontal or vertical." publicfield="false" guid="df0b2382-6a9d-468f-a973-83c3c7f9c742" visibility="none" translatefield="true"><settings><controlname>dropdownlistcontrol</controlname><Options>&lt;item value="horizontal" text="Horizontal" /&gt;&lt;item value="vertical" text="Vertical" /&gt;</Options></settings></field><field column="HideCurrentCulture" fieldcaption="Hide current culture" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" fielddescription="Indicates whether the link for the currently selected culture should be hidden." publicfield="false" guid="3c4acdf9-4ed6-4337-92aa-4a88aa238eaf" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" fieldcaption="Hide unavailable cultures" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.hideunavaliblecultures$}" publicfield="false" guid="e1d55695-713e-4fa1-8f29-6d493c4515b2" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" fieldcaption="Use culture specific URLs" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.generateurlswithlangprefix$}" publicfield="false" guid="76d686d3-d265-451b-b8d2-55fcc11fac3f" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache" caption="Content cache" visible="True" /><field column="CacheMinutes" fieldcaption="Cache minutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.cacheminutes$}" publicfield="false" guid="0f070cff-ae4b-4879-a909-e286cfc7cede" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="CacheByQueryStringParameters" fieldcaption="Query string parameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" fielddescription="{$documentation.webpartproperties.cachebyqueryparameters$}" publicfield="false" guid="c1c8873d-76d3-4dc2-a83f-9800ad7cf7cf" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field></form>'
	WHERE [WebPartName] = 'languageselection';

	-- Correct 'Language selection drop-down' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form><category name="Layout" visible="True" /><field column="ShowCultureNames" fieldcaption="Show culture names" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates if the names of the available cultures should be displayed. If disabled, only the flags matching the given cultures will be shown." publicfield="false" guid="92df5090-fcc6-4969-bb1e-bce506cf8714" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideCurrentCulture" fieldcaption="Hide current culture" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" fielddescription="Indicates whether the item representing the currently selected culture should be hidden." publicfield="false" spellcheck="false" guid="37ef1dc3-1011-4ad1-b1f6-9034d8f866b4" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideIfOneCulture" fieldcaption="Hide if there is only one culture" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" fielddescription="If enabled, the drop-down list will be hidden if there is only one culture assigned to the site." publicfield="false" spellcheck="false" guid="7359b4dd-384b-4df8-b095-d9198ba483f9" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" fieldcaption="Hide unavailable cultures" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates whether cultures that are not available for the current document should be hidden in the list." publicfield="false" guid="17742874-d2d4-4d8f-97d6-08a9a8505c64" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" fieldcaption="Use culture specific URLs" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.generateurlswithlangprefix$}" publicfield="false" guid="04eb4e84-4586-4d08-ad8b-0ef2392b4004" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache" caption="Content cache" visible="True" /><field column="CacheMinutes" fieldcaption="Cache minutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.cacheminutes$}" publicfield="false" guid="097904ed-5a9f-4416-bac2-b5e691e458d6" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="CacheByQueryStringParameters" fieldcaption="Query string parameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" fielddescription="{$documentation.webpartproperties.cachebyqueryparameters$}" publicfield="false" guid="166838c1-e7b2-45cf-b54b-4c51b4309bf3" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field></form>'
	WHERE [WebPartName] = 'languageselectiondropdown';

	-- Correct 'Language selection with flags' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form><category name="Layout" visible="True" /><field column="DisplayLayout" fieldcaption="Display layout" visible="true" defaultvalue="horizontal" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="50" fielddescription="Determines the orientation of the list of language selection links. Possible options are horizontal or vertical." publicfield="false" guid="10e6554e-9af3-4a3c-b3d9-3145463335eb" visibility="none" translatefield="true"><settings><controlname>dropdownlistcontrol</controlname><Options>&lt;item value="horizontal" text="Horizontal" /&gt;&lt;item value="vertical" text="Vertical" /&gt;</Options></settings></field><field column="ShowCultureNames" fieldcaption="Show culture names" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates if the names of the available cultures should be displayed. If disabled, only the flags matching the given cultures will be shown." publicfield="false" guid="f062feda-7123-4045-a060-1244937dea41" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="Separator" fieldcaption="Separator" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" fielddescription="Defines the HTML code of the separator placed between individual culture links." publicfield="false" guid="24f9a476-9274-4a3f-8cb9-74a95e3b8934" visibility="none" translatefield="true"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="HideCurrentCulture" fieldcaption="Hide current culture" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" fielddescription="Indicates whether the link for the currently selected culture should be hidden." publicfield="false" guid="4d2b45a8-8a66-48b7-b289-ad27bf6b77a4" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" fieldcaption="Hide unavailable cultures" visible="true" defaultvalue="false" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.hideunavaliblecultures$}" publicfield="false" guid="d1d3c436-dd6c-476f-b5a9-ff6e51203adb" visibility="none" translatefield="true"><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" fieldcaption="Use culture specific URLs" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.generateurlswithlangprefix$}" publicfield="false" guid="d3711dd1-1d0b-4c09-a507-1a0fbcc16ede" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache" caption="Content cache" visible="True" /><field column="CacheMinutes" fieldcaption="Cache minutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="{$documentation.webpartproperties.cacheminutes$}" publicfield="false" guid="8bcaa87d-846d-4a76-ada1-408a187e9266" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="CacheByQueryStringParameters" fieldcaption="Query string parameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" fielddescription="{$documentation.webpartproperties.cachebyqueryparameters$}" publicfield="false" guid="ff16a7fe-279c-4f3a-8df4-4063a160d6ac" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field></form>'
	WHERE [WebPartName] = 'languageselectionwithflags';
END
GO


-- TES-584 - Renaming a document with large number of child documents could lead to timeout issue with 'Remember original URLs when moving pages' setting turned on.
GO
ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10),
 @GenerateAliases bit
AS
BEGIN
	DECLARE @nodeParentId int;
	DECLARE @parentDocumentCulture nvarchar(10);
	DECLARE @parentUseNamePathForUrlPath bit;
	DECLARE @parentDocumentUrlPath nvarchar(450);
	DECLARE @parentDocumentNamePath nvarchar(1500);
	DECLARE @documentUseNamePathForUrlPath bit;
	DECLARE @updatedChildren int;

	-- Cursor for all parent culture vesions in current level
	DECLARE @parentCursor CURSOR;

	-- Temp table for all parent culture vesions in current level
	DECLARE @parents TABLE (
		NodeParentID int,
		DocumentCulture nvarchar(10)
	);

	-- Get all parent culture versions in current level
	INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined_Regular WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID

	-- Iterate through parent culture versions
	SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
	OPEN @parentCursor
	FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture

	-- There is parent document to process
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Get best match (culture version) for parent document URL path and name path (including parent link documents)
		SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath 
			FROM (SELECT TOP 1 DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
				FROM View_CMS_Tree_Joined 
					WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
			ORDER BY Priority ASC) TopParentPath;

		-- Document aliases should be generated		
		IF (@GenerateAliases = 1)
		BEGIN
			-- Insert alias for all child documents where original URL path differs from the new one and the alias with same URL path doesn't exist
			INSERT INTO CMS_DocumentAlias (AliasNodeID, AliasCulture, AliasURLPath, AliasExtensions, AliasCampaign, AliasWildcardRule, AliasPriority, AliasGUID, AliasLastModified, AliasSiteID)
				SELECT NodeID AS AliasNodeID, DocumentCulture AS AliasCulture, DocumentURLPath AS AliasURLPath, '' AS AliasExtensions, '' AS AliasCampaign, '' AS AliasWildcardRule, 1 AS AliasPriority, NEWID() AS AliasGUID, GETDATE() AS AliasLastModified, @SiteID AS AliasSiteID
					FROM View_CMS_Tree_Joined 
						-- For all child documents in the same culture
						WHERE NodeParentID = @nodeParentId AND DocumentCulture = @parentDocumentCulture 
						-- URL path is used and differs from the original one
						AND DocumentUrlPath <> (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
						-- There is no alias with the same URL path
						AND NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = DocumentUrlPath AND AliasNodeID = NodeID AND (AliasCulture = DocumentCulture OR ISNULL(AliasCulture, '') = ''))
		END
				
		-- Update name path and URL path for all child documents in parent culture
		UPDATE CMS_Document SET 
			DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, 
			DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND  (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
			-- In the same culture
			WHERE DocumentCulture = @parentDocumentCulture
			-- All child documents
			AND DocumentNodeID IN (SELECT NodeID FROM CMS_Tree WHERE NodeParentID = @nodeParentId) 
		
		-- Store number of updated child documents
		SET @updatedChildren = @@ROWCOUNT

		-- Get next parent
		FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	END
	
	CLOSE @parentCursor;
	DEALLOCATE @parentCursor;
	-- All parents in level processed

	-- There are child documents to process
	IF @updatedChildren <> 0
	BEGIN
		-- Process next level
		SET @NodeLevel = @NodeLevel + 1;
		EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode, @GenerateAliases;															
	END
END
GO

/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '103' WHERE KeyName = N'CMSHotfixVersion'
GO















